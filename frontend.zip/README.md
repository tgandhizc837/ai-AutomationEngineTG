src/
│
├── app/
│   ├── (auth)/
│   │   ├── login/
│   │   │   └── page.tsx
│   │   ├── signup/
│   │   │   └── page.tsx
│   │   └── layout.tsx
│   │
│   ├── dashboard/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   ├── projects/
│   │   │   ├── page.tsx
│   │   │   └── [projectId]/
│   │   │       ├── page.tsx
│   │   │       └── tests/
│   │   │           ├── page.tsx
│   │   │           └── [testId]/
│   │   │               ├── page.tsx
│   │   │               └── execution/
│   │   │                   └── [executionId]/
│   │   │                       └── page.tsx
│   │   ├── executions/
│   │   │   └── page.tsx
│   │   ├── billing/
│   │   │   └── page.tsx
│   │   └── settings/
│   │       └── page.tsx
│
├── components/
│   ├── layout/
│   │   ├── AppShell.tsx
│   │   ├── Sidebar.tsx
│   │   ├── TopNavbar.tsx
│   │   └── WorkspaceSwitcher.tsx
│   │
│   ├── dashboard/
│   │   ├── KPIGrid.tsx
│   │   ├── ExecutionTrendChart.tsx
│   │   ├── SuccessRateChart.tsx
│   │   └── RecentExecutionsTable.tsx
│   │
│   ├── projects/
│   │   ├── ProjectCard.tsx
│   │   ├── ProjectGrid.tsx
│   │   └── CreateProjectModal.tsx
│   │
│   ├── tests/
│   │   ├── TestTable.tsx
│   │   ├── TestRow.tsx
│   │   ├── TestEditor.tsx
│   │   └── RunTestButton.tsx
│   │
│   ├── execution/
│   │   ├── ExecutionHeader.tsx
│   │   ├── ExecutionMetadataBar.tsx
│   │   ├── StepTimeline.tsx
│   │   ├── StepItem.tsx
│   │   ├── StepDetailPanel.tsx
│   │   └── ExecutionStatusBadge.tsx
│   │
│   ├── billing/
│   │   ├── PlanCard.tsx
│   │   ├── UsageChart.tsx
│   │   └── UpgradeModal.tsx
│   │
│   └── ui/              (Reusable Design System)
│       ├── Button.tsx
│       ├── Badge.tsx
│       ├── Card.tsx
│       ├── Modal.tsx
│       ├── Table.tsx
│       ├── Spinner.tsx
│       └── Input.tsx
│
├── hooks/
│   ├── useWorkspace.ts
│   ├── useProjects.ts
│   ├── useTests.ts
│   ├── useExecutions.ts
│   └── useExecutionLive.ts
│
├── lib/
│   ├── api.ts
│   ├── queryClient.ts
│   ├── auth.ts
│   └── constants.ts
│
├── store/ (only if needed)
│   └── uiStore.ts
│
├── types/
│   ├── project.ts
│   ├── test.ts
│   ├── execution.ts
│   └── index.ts
│
└── providers/
    ├── ReactQueryProvider.tsx
    └── AuthProvider.tsx