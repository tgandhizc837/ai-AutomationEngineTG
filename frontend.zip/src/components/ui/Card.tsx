"use client";

import React from "react";

function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(" ");
}

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

export const Card: React.FC<CardProps> = ({
  children,
  className,
}) => {
  return (
    <div
      className={cn(
        "bg-white rounded-2xl shadow-sm border p-4",
        className
      )}
    >
      {children}
    </div>
  );
};