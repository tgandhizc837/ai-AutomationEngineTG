"use client";

import React from "react";

interface LoaderProps {
  size?: number;
}

export const Loader: React.FC<LoaderProps> = ({
  size = 24,
}) => {
  return (
    <div
      className="animate-spin rounded-full border-2 border-gray-300 border-t-blue-600"
      style={{
        width: size,
        height: size,
      }}
    />
  );
};