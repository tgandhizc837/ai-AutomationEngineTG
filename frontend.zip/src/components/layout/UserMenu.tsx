"use client";

import { useState } from "react";

const mockWorkspaces = [
  { id: "ws_1", name: "Acme Corp" },
  { id: "ws_2", name: "My Startup" },
];

export function WorkspaceSwitcher() {
  const [active, setActive] = useState(mockWorkspaces[0]);

  return (
    <div className="relative">
      <select
        value={active.id}
        onChange={(e) =>
          setActive(
            mockWorkspaces.find((w) => w.id === e.target.value)!
          )
        }
        className="bg-zinc-900 border border-zinc-700 text-sm rounded-md px-3 py-2"
      >
        {mockWorkspaces.map((ws) => (
          <option key={ws.id} value={ws.id}>
            {ws.name}
          </option>
        ))}
      </select>
    </div>
  );
}