"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

// ── Navigation structure ─────────────────────────────────────────
const NAV = [
  {
    section: "Overview",
    items: [
      { label: "Dashboard", href: "/dashboard", icon: "▦" },
    ],
  },
  {
    section: "Build",
    items: [
      {
        label: "Projects",
        href: "/dashboard/projects",
        icon: "⬡",
        sub: [
          { label: "All Projects",  href: "/dashboard/projects" },
          { label: "Add Project",   href: "/dashboard/projects/new" },
        ],
      },
      { label: "Executions",    href: "/dashboard/executions",    icon: "▶" },
      { label: "Import Excel",  href: "/dashboard/import-excel",  icon: "⬆" },
    ],
  },
  {
    section: "Manage",
    items: [
      { label: "Billing",  href: "/dashboard/billing",  icon: "💳" },
      { label: "Settings", href: "/dashboard/settings", icon: "⚙" },
    ],
  },
];

export function Sidebar() {
  const pathname = usePathname();
  // Track which top-level items with sub-menus are open
  const [open, setOpen] = useState<Record<string, boolean>>({
    "/dashboard/projects": true, // projects open by default
  });

  const toggle = (href: string) =>
    setOpen((prev) => ({ ...prev, [href]: !prev[href] }));

  return (
    <aside className="w-60 shrink-0 bg-zinc-900 border-r border-zinc-800 flex flex-col">
      {/* Logo */}
      <div className="h-14 flex items-center px-5 border-b border-zinc-800">
        <span className="text-white font-bold text-sm tracking-wide">
          AI Test Engine
        </span>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-5 mt-2">
        {NAV.map((section) => (
          <div key={section.section}>
            <p className="text-[10px] font-semibold text-zinc-500 uppercase tracking-widest px-2 mb-1">
              {section.section}
            </p>

            <div className="space-y-0.5">
              {section.items.map((item) => {
                const hasSub   = "sub" in item && (item as any).sub?.length > 0;
                const isOpen   = open[item.href];
                const isActive = pathname === item.href ||
                  (hasSub && pathname.startsWith(item.href));

                return (
                  <div key={item.href}>
                    {/* Parent row */}
                    <div
                      className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm cursor-pointer select-none transition-colors ${
                        isActive
                          ? "bg-zinc-800 text-white"
                          : "text-zinc-400 hover:bg-zinc-800 hover:text-white"
                      }`}
                      onClick={() =>
                        hasSub ? toggle(item.href) : undefined
                      }
                    >
                      {!hasSub ? (
                        <Link href={item.href} className="flex items-center gap-2 flex-1">
                          <span className="text-xs">{item.icon}</span>
                          {item.label}
                        </Link>
                      ) : (
                        <>
                          <span className="text-xs">{item.icon}</span>
                          <span className="flex-1">{item.label}</span>
                          <span className="text-zinc-600 text-xs">
                            {isOpen ? "▾" : "▸"}
                          </span>
                        </>
                      )}
                    </div>

                    {/* Sub-items */}
                    {hasSub && isOpen && (
                      <div className="ml-4 mt-0.5 space-y-0.5 border-l border-zinc-800 pl-3">
                        {(item as any).sub.map((sub: { label: string; href: string }) => {
                          const subActive = pathname === sub.href;
                          return (
                            <Link
                              key={sub.href}
                              href={sub.href}
                              className={`flex items-center gap-2 px-2 py-1.5 rounded-md text-xs transition-colors ${
                                subActive
                                  ? "text-white bg-zinc-800"
                                  : "text-zinc-500 hover:text-white hover:bg-zinc-800"
                              }`}
                            >
                              {sub.label === "Add Project" ? (
                                <>
                                  <span className="text-blue-400 font-bold">+</span>
                                  {sub.label}
                                </>
                              ) : (
                                <>
                                  <span className="text-zinc-600">—</span>
                                  {sub.label}
                                </>
                              )}
                            </Link>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </nav>
    </aside>
  );
}
