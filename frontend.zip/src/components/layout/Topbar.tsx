"use client";

import { WorkspaceSwitcher } from "./WorkspaceSwitcher";

function UserMenu() {
  return (
    <div className="flex items-center space-x-3">
      <button className="text-sm text-white">Sign in</button>
    </div>
  );
}

export function Topbar() {
  return (
    <header className="h-16 border-b border-zinc-800 bg-black flex items-center justify-between px-6">
      <WorkspaceSwitcher />
      <UserMenu />
    </header>
  );
}