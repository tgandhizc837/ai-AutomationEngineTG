"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { apiFetch } from "@/lib/api";

type User = {
  id: string;
  workspaceId?: string;
};

type AuthContextType = {
  user: User | null;
  loading: boolean;
  refresh: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  async function refresh() {
    console.log("🔄 Refresh called");
    setLoading(true);

    try {
      const data = await apiFetch("/auth/me");
      console.log("✅ /auth/me response:", data);

      // ✅ FIX: correct structure
      if (data?.user) {
        setUser({
          id: data.user.id,
          workspaceId: data.user.workspace_id ?? undefined, // DB returns snake_case
        });

        console.log("👤 User set:", data.user);
      } else {
        console.log("❌ No user in response");
        setUser(null);
      }
    } catch (err) {
      console.error("💥 Refresh error:", err);
      setUser(null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, refresh }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}