export const navigation = [
  {
    section: "Overview",
    items: [
      { label: "Dashboard", href: "/dashboard" },
    ],
  },
  {
    section: "Build",
    items: [
      { label: "Projects", href: "/dashboard/projects" },
      { label: "Tests", href: "/dashboard/tests" },
    ],
  },
  {
    section: "Run",
    items: [
      { label: "Executions", href: "/dashboard/executions" },
    ],
  },
  {
    section: "Manage",
    items: [
      { label: "Billing", href: "/dashboard/billing" },
      { label: "Settings", href: "/dashboard/settings" },
    ],
  },
];