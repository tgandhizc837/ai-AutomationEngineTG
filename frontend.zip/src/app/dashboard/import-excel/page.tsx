"use client";

import { useRef, useState } from "react";
import { useAuth } from "@/providers/AuthProvider";
import { ProjectAPI, Project, Test } from "@/modules/project/project.api";
import { useEffect } from "react";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

interface ConvertedTest {
  name: string;
  gherkin: string;
}

type SaveStatus = "idle" | "saving" | "saved" | "error";

export default function ImportExcelPage() {
  const { user } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [converting, setConverting] = useState(false);
  const [results, setResults] = useState<ConvertedTest[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Save-to-project state
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectsLoading, setProjectsLoading] = useState(false);
  const [selectedProject, setSelectedProject] = useState<string>("");
  const [saveStatus, setSaveStatus] = useState<Record<number, SaveStatus>>({});
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  // Load projects when results are available
  useEffect(() => {
    if (results.length === 0 || !user?.workspaceId) return;
    setProjectsLoading(true);
    ProjectAPI.list(user.workspaceId)
      .then((data) => setProjects(data))
      .catch(() => {})
      .finally(() => setProjectsLoading(false));
  }, [results.length, user?.workspaceId]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const picked = e.target.files?.[0] ?? null;
    setFile(picked);
    setResults([]);
    setError(null);
    setSaveStatus({});
  };

  const handleConvert = async () => {
    if (!file) return;
    setConverting(true);
    setError(null);
    setResults([]);
    setSaveStatus({});

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch(`${BASE_URL}/tests/import-excel`, {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      let data: any;
      try {
        data = await res.json();
      } catch {
        throw new Error("Invalid response from server");
      }

      if (!res.ok) {
        throw new Error(data?.error || `Server error ${res.status}`);
      }

      setResults(data.results ?? []);
      if ((data.results ?? []).length === 0) {
        setError("No test cases found. Ensure the file has a 'Summary' column.");
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setConverting(false);
    }
  };

  const handleSaveOne = async (index: number) => {
    if (!selectedProject) {
      setError("Please select a project to save to.");
      return;
    }
    setSaveStatus((s) => ({ ...s, [index]: "saving" }));
    try {
      await ProjectAPI.createTest({
        project_id: selectedProject,
        name: results[index].name,
        gherkin: results[index].gherkin,
      });
      setSaveStatus((s) => ({ ...s, [index]: "saved" }));
    } catch (err: any) {
      setSaveStatus((s) => ({ ...s, [index]: "error" }));
    }
  };

  const handleSaveAll = async () => {
    if (!selectedProject) {
      setError("Please select a project to save to.");
      return;
    }
    for (let i = 0; i < results.length; i++) {
      if (saveStatus[i] === "saved") continue;
      await handleSaveOne(i);
    }
  };

  const allSaved =
    results.length > 0 && results.every((_, i) => saveStatus[i] === "saved");

  return (
    <div className="space-y-8 max-w-5xl">
      {/* ── Header ── */}
      <div>
        <h1 className="text-2xl font-semibold text-white">Import from Excel</h1>
        <p className="text-sm text-zinc-500 mt-1">
          Upload an Excel file with test case columns and convert them to Gherkin automatically.
        </p>
      </div>

      {/* ── Expected format info ── */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-3">
        <p className="text-sm font-semibold text-zinc-300">Expected Excel Columns</p>
        <p className="text-xs text-zinc-500">
          Column names are matched flexibly — any header containing a keyword below will work.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[
            {
              label: "Summary",
              required: true,
              aliases: "Summary, Title, Description, Test Name, Test Case, Test Summary, Scenario, Name",
            },
            {
              label: "Test Steps",
              required: false,
              aliases: "Test Steps, Steps, Actions, Procedure, Instructions, Steps to Reproduce",
            },
            {
              label: "Test Data",
              required: false,
              aliases: "Test Data, Data, Input, Parameters, Values",
            },
            {
              label: "Expected Result",
              required: false,
              aliases: "Expected Result, Expected, Expected Output, Acceptance Criteria, Outcome",
            },
            {
              label: "Pre Requisite",
              required: false,
              aliases: "Pre Requisite, Prerequisite, Precondition, Pre Condition, Setup",
            },
          ].map((col) => (
            <div
              key={col.label}
              className="flex flex-col gap-1 px-3 py-2 rounded-lg bg-zinc-800"
            >
              <div className="flex items-center gap-2">
                <span
                  className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                    col.required ? "bg-blue-400" : "bg-zinc-600"
                  }`}
                />
                <span className="text-xs font-semibold text-zinc-200">{col.label}</span>
                {col.required && (
                  <span className="text-blue-400 text-[10px]">required</span>
                )}
              </div>
              <p className="text-[11px] text-zinc-500 pl-3.5">{col.aliases}</p>
            </div>
          ))}
        </div>
        <p className="text-xs text-zinc-600">Supports .xlsx, .xls, and .csv files.</p>
      </div>

      {/* ── Upload zone ── */}
      <div
        className="border-2 border-dashed border-zinc-700 hover:border-zinc-500 rounded-xl p-10 flex flex-col items-center justify-center gap-4 cursor-pointer transition-colors"
        onClick={() => fileRef.current?.click()}
      >
        <input
          ref={fileRef}
          type="file"
          accept=".xlsx,.xls,.csv"
          className="hidden"
          onChange={handleFileChange}
        />
        <div className="text-4xl text-zinc-600">📊</div>
        {file ? (
          <div className="text-center space-y-1">
            <p className="text-sm font-semibold text-white">{file.name}</p>
            <p className="text-xs text-zinc-500">
              {(file.size / 1024).toFixed(1)} KB — click to change
            </p>
          </div>
        ) : (
          <div className="text-center space-y-1">
            <p className="text-sm font-semibold text-zinc-300">
              Click to upload or drag &amp; drop
            </p>
            <p className="text-xs text-zinc-600">.xlsx, .xls, .csv up to 10 MB</p>
          </div>
        )}
      </div>

      {/* ── Convert button ── */}
      {file && (
        <button
          onClick={handleConvert}
          disabled={converting}
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-semibold rounded-lg transition-colors flex items-center gap-2"
        >
          {converting ? (
            <>
              <span className="animate-spin">⟳</span> Converting…
            </>
          ) : (
            "✦ Convert to Gherkin"
          )}
        </button>
      )}

      {/* ── Error ── */}
      {error && (
        <div className="text-sm text-red-400 bg-red-950/40 border border-red-800 rounded-xl px-4 py-3">
          {error}
        </div>
      )}

      {/* ── Results ── */}
      {results.length > 0 && (
        <div className="space-y-5">
          {/* Save controls */}
          <div className="flex flex-wrap items-center gap-3 bg-zinc-900 border border-zinc-800 rounded-xl p-4">
            <span className="text-sm text-zinc-400 font-medium">
              {results.length} scenario{results.length !== 1 ? "s" : ""} converted
            </span>

            <div className="flex-1 min-w-[200px]">
              {projectsLoading ? (
                <p className="text-xs text-zinc-500">Loading projects…</p>
              ) : projects.length === 0 ? (
                <p className="text-xs text-amber-400">
                  No projects found. Create a project first.
                </p>
              ) : (
                <select
                  value={selectedProject}
                  onChange={(e) => {
                    setSelectedProject(e.target.value);
                    setError(null);
                  }}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select a project to save to…</option>
                  {projects.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              )}
            </div>

            {!allSaved && (
              <button
                onClick={handleSaveAll}
                disabled={!selectedProject || allSaved}
                className="px-4 py-1.5 bg-green-600 hover:bg-green-700 disabled:opacity-40 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap"
              >
                Save All to Project
              </button>
            )}

            {allSaved && (
              <span className="text-sm text-green-400 font-medium">
                ✓ All saved
              </span>
            )}
          </div>

          {/* Scenario cards */}
          <div className="space-y-3">
            {results.map((item, i) => {
              const status = saveStatus[i] ?? "idle";
              const isExpanded = expandedIndex === i;

              return (
                <div
                  key={i}
                  className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden"
                >
                  {/* Card header */}
                  <div
                    className="flex items-center justify-between px-5 py-4 cursor-pointer hover:bg-zinc-800/50 transition-colors"
                    onClick={() => setExpandedIndex(isExpanded ? null : i)}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="text-zinc-600 text-xs font-mono shrink-0">
                        #{i + 1}
                      </span>
                      <span className="text-sm font-medium text-white truncate">
                        {item.name}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 ml-3">
                      {status === "saving" && (
                        <span className="text-xs text-zinc-400 animate-pulse">
                          Saving…
                        </span>
                      )}
                      {status === "saved" && (
                        <span className="text-xs text-green-400">✓ Saved</span>
                      )}
                      {status === "error" && (
                        <span className="text-xs text-red-400">Failed</span>
                      )}
                      {(status === "idle" || status === "error") && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSaveOne(i);
                          }}
                          disabled={!selectedProject}
                          className="px-3 py-1 bg-zinc-700 hover:bg-zinc-600 disabled:opacity-40 text-xs text-white rounded-md transition-colors"
                        >
                          Save
                        </button>
                      )}
                      <span className="text-zinc-600 text-xs ml-1">
                        {isExpanded ? "▾" : "▸"}
                      </span>
                    </div>
                  </div>

                  {/* Gherkin preview */}
                  {isExpanded && (
                    <div className="border-t border-zinc-800 px-5 py-4">
                      <pre className="text-xs text-green-300 bg-zinc-950 rounded-lg p-4 overflow-x-auto whitespace-pre-wrap font-mono leading-relaxed">
                        {item.gherkin}
                      </pre>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
