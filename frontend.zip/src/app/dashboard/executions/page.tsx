"use client";

import { useEffect, useState } from "react";
import { ExecutionAPI } from "@/modules/execution/api/execution.api";
import ExecutionTimeline from "@/modules/execution/components/ExecutionTimeline";

// ── Types ────────────────────────────────────────────────────────────────────
interface ExecRow {
  id: string;
  status: "queued" | "running" | "completed" | "failed";
  created_at: string;
  started_at?: string;
  completed_at?: string;
  browser?: string;
  test_id: string;
  test_name: string;
  project_id: string;
  project_name: string;
}

type StatusFilter = "all" | "completed" | "failed" | "running" | "queued";

// ── Helpers ──────────────────────────────────────────────────────────────────
function durationSec(row: ExecRow): number | null {
  if (!row.started_at || !row.completed_at) return null;
  return Math.round(
    (new Date(row.completed_at).getTime() - new Date(row.started_at).getTime()) / 1000
  );
}

function StatusBadge({ status }: { status: ExecRow["status"] }) {
  const map: Record<ExecRow["status"], { label: string; cls: string }> = {
    completed: { label: "Completed", cls: "text-green-400" },
    failed:    { label: "Failed",    cls: "text-red-400"   },
    running:   { label: "Running",   cls: "text-yellow-400" },
    queued:    { label: "Queued",    cls: "text-zinc-400"  },
  };
  const { label, cls } = map[status] ?? { label: status, cls: "text-zinc-400" };
  return <span className={`font-semibold text-xs ${cls}`}>{label}</span>;
}

function ResultPill({ status }: { status: ExecRow["status"] }) {
  if (status === "completed")
    return <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-green-600 text-white">Pass</span>;
  if (status === "failed")
    return <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-red-600 text-white">Fail</span>;
  return <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-zinc-600 text-white">—</span>;
}

function BrowserBadge({ browser }: { browser?: string }) {
  const label =
    browser === "firefox" ? "🦊 Firefox"
    : browser === "webkit"  ? "🧭 Safari"
    : browser === "msedge"  ? "🟦 Edge"
    : browser === "chrome"  ? "🌐 Chrome"
    : "🔵 Chromium";
  return (
    <span className="text-zinc-400 text-xs truncate" title={browser ?? "chromium"}>
      {label}
    </span>
  );
}

// ── Page ─────────────────────────────────────────────────────────────────────
export default function ExecutionsPage() {
  const [rows,        setRows]        = useState<ExecRow[]>([]);
  const [loading,     setLoading]     = useState(true);
  const [error,       setError]       = useState<string | null>(null);

  // Filters
  const [statusFilter,  setStatusFilter]  = useState<StatusFilter>("all");
  const [projectFilter, setProjectFilter] = useState<string>("all");
  const [search,        setSearch]        = useState("");

  // Expanded step viewer
  const [viewingId, setViewingId] = useState<string | null>(null);

  // ── Fetch ─────────────────────────────────────────────────────
  useEffect(() => {
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const data = (await ExecutionAPI.listAll()) as ExecRow[];
        setRows(data);
      } catch (e: any) {
        setError(e.message ?? "Failed to load executions");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // ── Derived ───────────────────────────────────────────────────
  const projects = Array.from(new Set(rows.map((r) => r.project_name))).sort();

  const filtered = rows.filter((r) => {
    if (statusFilter  !== "all" && r.status !== statusFilter) return false;
    if (projectFilter !== "all" && r.project_name !== projectFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      if (!r.test_name.toLowerCase().includes(q) && !r.project_name.toLowerCase().includes(q))
        return false;
    }
    return true;
  });

  const total     = rows.length;
  const passed    = rows.filter((r) => r.status === "completed").length;
  const failed    = rows.filter((r) => r.status === "failed").length;
  const running   = rows.filter((r) => r.status === "running" || r.status === "queued").length;

  // ── Render ────────────────────────────────────────────────────
  return (
    <div className="space-y-6">

      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-white">Executions</h1>
        <p className="text-xs text-zinc-500 mt-0.5">All test runs across every project</p>
      </div>

      {/* Summary bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Total Runs",  value: total,   cls: "text-white"        },
          { label: "Passed",      value: passed,  cls: "text-green-400"    },
          { label: "Failed",      value: failed,  cls: "text-red-400"      },
          { label: "In Progress", value: running, cls: "text-yellow-400"   },
        ].map(({ label, value, cls }) => (
          <div key={label} className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 text-center">
            <p className={`text-2xl font-bold ${cls}`}>{value}</p>
            <p className="text-xs text-zinc-500 mt-1">{label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Search */}
        <input
          type="text"
          placeholder="Search test or project…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="flex-1 min-w-[180px] bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        {/* Status filter */}
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
          className="bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="all">All Statuses</option>
          <option value="completed">Completed</option>
          <option value="failed">Failed</option>
          <option value="running">Running</option>
          <option value="queued">Queued</option>
        </select>

        {/* Project filter */}
        <select
          value={projectFilter}
          onChange={(e) => setProjectFilter(e.target.value)}
          className="bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="all">All Projects</option>
          {projects.map((p) => (
            <option key={p} value={p}>{p}</option>
          ))}
        </select>

        <span className="text-xs text-zinc-500 ml-auto">
          {filtered.length} of {total} runs
        </span>
      </div>

      {/* Table */}
      {loading ? (
        <p className="text-xs text-zinc-500 animate-pulse">Loading executions…</p>
      ) : error ? (
        <p className="text-xs text-red-400">{error}</p>
      ) : filtered.length === 0 ? (
        <p className="text-xs text-zinc-500">No executions match the current filters.</p>
      ) : (
        <div className="border border-zinc-800 rounded-xl overflow-hidden">
          {/* Table head */}
          <div className="grid grid-cols-[1fr_1fr_1fr_90px_70px_80px_60px_90px] gap-2 px-4 py-2 bg-zinc-900 border-b border-zinc-800 text-xs font-semibold text-zinc-500 uppercase tracking-wide">
            <span>Date / Time</span>
            <span>Project</span>
            <span>Test Name</span>
            <span>Status</span>
            <span>Result</span>
            <span>Browser</span>
            <span>Duration</span>
            <span></span>
          </div>

          {/* Rows */}
          <div className="divide-y divide-zinc-800/60">
            {filtered.map((exec) => {
              const dur = durationSec(exec);
              const isViewing = viewingId === exec.id;
              return (
                <div key={exec.id}>
                  {/* Row */}
                  <div className="grid grid-cols-[1fr_1fr_1fr_90px_70px_80px_60px_90px] gap-2 px-4 py-3 text-xs items-center hover:bg-zinc-900/60 transition-colors">
                    {/* Date */}
                    <span className="text-zinc-300 font-mono truncate">
                      {new Date(exec.created_at).toLocaleString()}
                    </span>

                    {/* Project */}
                    <span className="text-zinc-300 truncate">{exec.project_name}</span>

                    {/* Test name */}
                    <span className="text-white font-medium truncate">{exec.test_name}</span>

                    {/* Exec status */}
                    <StatusBadge status={exec.status} />

                    {/* Result pill */}
                    <ResultPill status={exec.status} />

                    {/* Browser */}
                    <BrowserBadge browser={exec.browser} />

                    {/* Duration */}
                    <span className="text-zinc-500">
                      {dur !== null ? `${dur}s` : "—"}
                    </span>

                    {/* Actions */}
                    <button
                      onClick={() => setViewingId(isViewing ? null : exec.id)}
                      className={`px-3 py-1 rounded-md text-xs font-semibold border transition-colors ${
                        isViewing
                          ? "border-zinc-500 bg-zinc-700 text-white hover:bg-zinc-600"
                          : "border-blue-500 bg-blue-600 text-white hover:bg-blue-500"
                      }`}
                    >
                      {isViewing ? "Close" : "View Steps"}
                    </button>
                  </div>

                  {/* Inline step viewer */}
                  {isViewing && (
                    <div className="px-4 pb-4 bg-zinc-950 border-t border-zinc-800">
                      <ExecutionTimeline executionId={exec.id} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
