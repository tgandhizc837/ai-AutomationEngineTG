"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/providers/AuthProvider";
import { ProjectAPI } from "@/modules/project/project.api";

export default function NewProjectPage() {
  const { user } = useAuth();
  const router   = useRouter();

  const [name,      setName]      = useState("");
  const [baseUrl,   setBaseUrl]   = useState("");
  const [saving,    setSaving]    = useState(false);
  const [error,     setError]     = useState<string | null>(null);
  const [created,   setCreated]   = useState<{ id: string; name: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // ── Debug: show exactly what workspaceId we have ──
    console.log("📝 [NewProject] user state:", user);

    if (!user?.workspaceId) {
      const msg = `No workspace ID found in user session. user = ${JSON.stringify(user)}`;
      console.error("❌ [NewProject]", msg);
      setError("No workspace found — please reload the page or log out and back in.");
      return;
    }

    setSaving(true);
    try {
      console.log("🚀 [NewProject] POSTing to /projects with:", {
        workspace_id: user.workspaceId,
        name: name.trim(),
        base_url: baseUrl.trim() || null,
      });
      const project = await ProjectAPI.create({
        workspace_id: user.workspaceId,
        name:         name.trim(),
        base_url:     baseUrl.trim() || undefined,
      });
      console.log("✅ [NewProject] Created:", project);
      setCreated({ id: project.id, name: project.name });
    } catch (err: any) {
      console.error("❌ [NewProject] Create failed:", err);
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-xl space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-white">Add Project</h1>
        <p className="text-sm text-zinc-500 mt-1">
          A project groups all tests for one web application.
        </p>
      </div>

      {/* ── Success state ── */}
      {created ? (
        <div className="bg-green-950/40 border border-green-700 rounded-xl p-6 space-y-4">
          <p className="text-green-300 font-semibold text-lg">
            ✅ Project &quot;{created.name}&quot; created successfully!
          </p>
          <p className="text-zinc-400 text-sm">ID: <span className="font-mono">{created.id}</span></p>
          <div className="flex gap-3">
            <button
              onClick={() => router.push(`/dashboard/projects/${created.id}`)}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors"
            >
              Open Project →
            </button>
            <button
              onClick={() => router.push("/dashboard/projects")}
              className="px-5 py-2.5 bg-zinc-700 hover:bg-zinc-600 text-white text-sm font-semibold rounded-lg transition-colors"
            >
              All Projects
            </button>
          </div>
        </div>
      ) : (
        /* ── Form ── */
        <form
          onSubmit={handleSubmit}
          className="bg-zinc-900 border border-zinc-700 rounded-xl p-6 space-y-5"
        >
          {/* Project name */}
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-zinc-300">
              Project name <span className="text-red-400">*</span>
            </label>
            <input
              required
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="My Web App"
              className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Base URL */}
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-zinc-300">
              Base URL
              <span className="text-zinc-500 font-normal ml-1.5">— the app under test</span>
            </label>
            <input
              type="url"
              value={baseUrl}
              onChange={(e) => setBaseUrl(e.target.value)}
              placeholder="https://your-app.com"
              className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="text-xs text-zinc-600">
              The engine navigates to this URL before running each test.
            </p>
          </div>

          {/* Error */}
          {error && (
            <div className="text-sm text-red-300 bg-red-950/50 border border-red-700 rounded-lg px-4 py-3 space-y-1">
              <p className="font-semibold">Error</p>
              <p>{error}</p>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3 pt-1">
            <button
              type="submit"
              disabled={saving || !user?.workspaceId}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-lg transition-colors"
            >
              {saving ? "Creating…" : "Create Project"}
            </button>
            <button
              type="button"
              onClick={() => router.push("/dashboard/projects")}
              className="px-5 py-2.5 bg-zinc-700 hover:bg-zinc-600 text-white text-sm font-semibold rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
