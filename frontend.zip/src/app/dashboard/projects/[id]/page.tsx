"use client";

import { useEffect, useRef, useState } from "react";
import { useParams } from "next/navigation";
import { ProjectAPI, Test } from "@/modules/project/project.api";
import RunTestButton from "@/modules/execution/components/RunTestButton";
import { ExecutionAPI } from "@/modules/execution/api/execution.api";
import ExecutionTimeline from "@/modules/execution/components/ExecutionTimeline";
import { ExecutionStatus as TStatus } from "@/modules/execution/types/execution.types";

// ── Tab type ──────────────────────────────────────────────────────
type InputMode = "write" | "upload";

// ── Default Gherkin template ──────────────────────────────────────
const TEMPLATE = `Feature: My Test

  Scenario: Example scenario
    Given I open "https://your-app.com"
    When I click "Login"
    And I enter "user@example.com" into "Email address"
    And I click "Next"
    Then I should see "Welcome"
`;

export default function ProjectDetailPage() {
  const { id: projectId } = useParams<{ id: string }>();

  const [project,    setProject]    = useState<null>(null);
  const [tests,      setTests]      = useState<Test[]>([]);
  const [loading,    setLoading]    = useState(true);

  // new-test form
  const [showForm,   setShowForm]   = useState(false);
  const [testName,   setTestName]   = useState("");
  const [gherkin,    setGherkin]    = useState(TEMPLATE);
  const [inputMode,  setInputMode]  = useState<InputMode>("write");
  const [saving,     setSaving]     = useState(false);
  const [formError,  setFormError]  = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  // which test has its run panel open
  const [activeTestId, setActiveTestId] = useState<string | null>(null);

  // last known executionId per test (persists across panel close/reopen)
  const [latestRunId,    setLatestRunId]    = useState<Record<string, string>>({});

  // live run status shown on card header
  const [liveStatus,     setLiveStatus]     = useState<Record<string, TStatus | null>>({});

  // per-test execution history
  const [historyOpen,    setHistoryOpen]    = useState<Record<string, boolean>>({});
  const [histories,      setHistories]      = useState<Record<string, any[]>>({});
  const [historyLoading, setHistoryLoading] = useState<Record<string, boolean>>({});
  const [viewingExecId,  setViewingExecId]  = useState<Record<string, string | null>>({});

  // ── Load project + tests ──────────────────────────────────────
  const load = async () => {
    setLoading(true);
    try {
      const testsData = await ProjectAPI.listTests(projectId);
      setTests(testsData);
    } catch {
      //
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [projectId]);

  const toggleHistory = async (testId: string) => {
    const opening = !historyOpen[testId];
    setHistoryOpen(h => ({ ...h, [testId]: opening }));
    if (opening) {
      // Always re-fetch so newly finished runs appear
      setHistoryLoading(h => ({ ...h, [testId]: true }));
      try {
        const runs = await ExecutionAPI.listByTest(testId);
        setHistories(h => ({ ...h, [testId]: runs as any[] }));
      } catch { /* ignore */ } finally {
        setHistoryLoading(h => ({ ...h, [testId]: false }));
      }
    }
  };

  const handleRunStarted = async (testId: string, executionId: string) => {
    setLatestRunId(m => ({ ...m, [testId]: executionId }));
    setLiveStatus(s => ({ ...s, [testId]: "running" }));
    // Auto-open history so the new queued entry appears immediately
    setHistoryOpen(h => ({ ...h, [testId]: true }));
    setHistoryLoading(h => ({ ...h, [testId]: true }));
    try {
      const runs = await ExecutionAPI.listByTest(testId);
      setHistories(h => ({ ...h, [testId]: runs as any[] }));
    } catch { /* ignore */ } finally {
      setHistoryLoading(h => ({ ...h, [testId]: false }));
    }
  };

  const handleTerminal = async (testId: string, status: TStatus) => {
    setLiveStatus(s => ({ ...s, [testId]: status }));
    // Keep history open and refresh so the finished run appears
    setHistoryOpen(h => ({ ...h, [testId]: true }));
    setHistoryLoading(h => ({ ...h, [testId]: true }));
    try {
      const runs = await ExecutionAPI.listByTest(testId);
      setHistories(h => ({ ...h, [testId]: runs as any[] }));
    } catch { /* ignore */ } finally {
      setHistoryLoading(h => ({ ...h, [testId]: false }));
    }
  };

  // ── File upload → extract text ────────────────────────────────
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setGherkin((ev.target?.result as string) ?? "");
    };
    reader.readAsText(file);
  };

  // ── Create test ───────────────────────────────────────────────
  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSaving(true);
    try {
      await ProjectAPI.createTest({
        project_id: projectId,
        name:       testName.trim(),
        gherkin:    gherkin.trim(),
      });
      setTestName("");
      setGherkin(TEMPLATE);
      setInputMode("write");
      setShowForm(false);
      await load();
    } catch (err: any) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">

      {/* ── Header ── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-white">Project Tests</h1>
        </div>
        <button
          onClick={() => { setShowForm(true); setFormError(null); }}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors"
        >
          + Add Test
        </button>
      </div>

      {/* ── Create test form ── */}
      {showForm && (
        <div className="border border-zinc-700 rounded-xl bg-zinc-900 p-6 space-y-5 max-w-3xl">
          <h2 className="text-lg font-semibold text-white">Add New Test</h2>

          <form onSubmit={handleCreate} className="space-y-5">

            {/* Test name */}
            <div>
              <label className="block text-sm text-zinc-400 mb-1">
                Test name <span className="text-red-400">*</span>
              </label>
              <input
                required
                value={testName}
                onChange={(e) => setTestName(e.target.value)}
                placeholder="Login flow"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Gherkin input mode tabs */}
            <div>
              <label className="block text-sm text-zinc-400 mb-2">
                Gherkin <span className="text-red-400">*</span>
              </label>

              {/* Mode toggle */}
              <div className="flex gap-1 mb-3 bg-zinc-800 p-1 rounded-lg w-fit">
                {(["write", "upload"] as InputMode[]).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setInputMode(m)}
                    className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-colors capitalize ${
                      inputMode === m
                        ? "bg-blue-600 text-white"
                        : "text-zinc-400 hover:text-white"
                    }`}
                  >
                    {m === "write" ? "✏️ Write" : "📁 Upload .feature file"}
                  </button>
                ))}
              </div>

              {/* Write mode */}
              {inputMode === "write" && (
                <textarea
                  required
                  rows={14}
                  value={gherkin}
                  onChange={(e) => setGherkin(e.target.value)}
                  spellCheck={false}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-4 py-3 text-sm text-green-300 font-mono placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-y"
                />
              )}

              {/* Upload mode */}
              {inputMode === "upload" && (
                <div className="space-y-3">
                  <div
                    onClick={() => fileRef.current?.click()}
                    className="border-2 border-dashed border-zinc-600 hover:border-blue-500 rounded-xl p-8 text-center cursor-pointer transition-colors"
                  >
                    <p className="text-zinc-400 text-sm">
                      Click to upload a <span className="text-white font-semibold">.feature</span> file
                    </p>
                    <p className="text-zinc-600 text-xs mt-1">Gherkin plain text</p>
                  </div>
                  <input
                    ref={fileRef}
                    type="file"
                    accept=".feature,.txt"
                    onChange={handleFileChange}
                    className="hidden"
                  />

                  {/* Preview after file loaded */}
                  {gherkin && gherkin !== TEMPLATE && (
                    <div className="bg-zinc-800 border border-zinc-700 rounded-lg p-4 max-h-48 overflow-auto">
                      <p className="text-xs text-zinc-500 mb-2">Preview</p>
                      <pre className="text-xs text-green-300 font-mono whitespace-pre-wrap">
                        {gherkin}
                      </pre>
                    </div>
                  )}
                </div>
              )}
            </div>

            {formError && <p className="text-sm text-red-400">{formError}</p>}

            <div className="flex gap-3">
              <button
                type="submit"
                disabled={saving}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-semibold rounded-lg transition-colors"
              >
                {saving ? "Saving…" : "Save Test"}
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-4 py-2 bg-zinc-700 hover:bg-zinc-600 text-white text-sm font-semibold rounded-lg transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ── Test list ── */}
      {loading ? (
        <p className="text-zinc-500 text-sm animate-pulse">Loading tests…</p>
      ) : tests.length === 0 ? (
        <div className="border border-dashed border-zinc-700 rounded-xl p-12 text-center">
          <p className="text-zinc-500 text-sm mb-3">No tests yet.</p>
          <button
            onClick={() => setShowForm(true)}
            className="text-blue-400 hover:text-blue-300 text-sm underline"
          >
            Add your first test
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {tests.map((t) => {
            const isRunning = activeTestId === t.id;
            return (
              <div
                key={t.id}
                className="border border-zinc-700 rounded-xl bg-zinc-900 overflow-hidden"
              >
                {/* ── Test header row ── */}
                <div className="flex items-center justify-between gap-4 px-5 py-4">
                  <div className="min-w-0 flex items-center gap-3">
                    <div>
                      <p className="text-white font-semibold text-sm truncate">{t.name}</p>
                      <p className="text-zinc-600 text-xs font-mono mt-0.5 truncate">{t.id}</p>
                    </div>
                    {/* Live status badge — updates in real-time during a run */}
                    {liveStatus[t.id] && (
                      <span className={`shrink-0 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold text-white ${
                        liveStatus[t.id] === "running"   ? "bg-blue-600 animate-pulse"
                        : liveStatus[t.id] === "completed" ? "bg-green-600"
                        : liveStatus[t.id] === "failed"    ? "bg-red-600"
                        : "bg-zinc-600"
                      }`}>
                        {liveStatus[t.id] === "running" && (
                          <span className="w-1.5 h-1.5 rounded-full bg-white opacity-80 animate-ping inline-block" />
                        )}
                        {liveStatus[t.id] === "running"   ? "Running"
                          : liveStatus[t.id] === "completed" ? "Completed"
                          : liveStatus[t.id] === "failed"    ? "Failed"
                          : liveStatus[t.id]}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={async () => {
                        const opening = !isRunning;
                        setActiveTestId(opening ? t.id : null);
                        if (opening) {
                          // Load history immediately when panel opens
                          setHistoryLoading(h => ({ ...h, [t.id]: true }));
                          try {
                            const runs = await ExecutionAPI.listByTest(t.id);
                            setHistories(h => ({ ...h, [t.id]: runs as any[] }));
                          } catch { /* ignore */ } finally {
                            setHistoryLoading(h => ({ ...h, [t.id]: false }));
                          }
                        }
                      }}
                      className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-colors ${
                        isRunning
                          ? "bg-zinc-700 hover:bg-zinc-600 text-white"
                          : "bg-blue-600 hover:bg-blue-700 text-white"
                      }`}
                    >
                      {isRunning ? "▼ Close" : "▶ Run Test"}
                    </button>
                  </div>
                </div>

                {/* ── Gherkin preview ── */}
                <details className="group px-5 pb-3">
                  <summary className="text-xs text-zinc-500 cursor-pointer select-none hover:text-zinc-300 list-none flex items-center gap-1">
                    <span className="group-open:rotate-90 transition-transform inline-block">▸</span>
                    View Gherkin
                  </summary>
                  <pre className="mt-2 bg-zinc-800 rounded-lg p-4 text-xs text-green-300 font-mono whitespace-pre-wrap overflow-auto max-h-48">
                    {t.gherkin}
                  </pre>
                </details>

                {/* ── Live run panel ── */}
                {isRunning && (
                  <div className="border-t border-zinc-700 px-5 py-4 bg-zinc-950">
                    <RunTestButton
                      testId={t.id}
                      projectId={projectId}
                      initialExecutionId={latestRunId[t.id] ?? null}
                      onRunStarted={(execId) => handleRunStarted(t.id, execId)}
                      onTerminal={(status) => handleTerminal(t.id, status)}
                    />
                  </div>
                )}

                {/* ── Execution History (shown when run panel is open) ── */}
                {isRunning && (
                  <div className="border-t border-zinc-800 bg-zinc-950 px-5 py-4 space-y-3">
                    <p className="text-xs font-semibold text-zinc-400 uppercase tracking-wide">Run History</p>
                    {historyLoading[t.id] ? (
                      <p className="text-xs text-zinc-500 animate-pulse">Loading…</p>
                    ) : !(histories[t.id]?.length) ? (
                      <p className="text-xs text-zinc-500">No previous runs.</p>
                    ) : (
                      <div className="space-y-2">
                        {(histories[t.id] || []).map((exec: any, idx: number) => {
                          const isViewing = viewingExecId[t.id] === exec.id;
                          const isLatest  = idx === 0;
                          const durationS = exec.started_at && exec.completed_at
                            ? Math.round(
                                (new Date(exec.completed_at).getTime() -
                                 new Date(exec.started_at).getTime()) / 1000
                              )
                            : null;
                          return (
                            <div key={exec.id} className={`space-y-2 ${isLatest ? "rounded-lg ring-1 ring-zinc-600 px-2 pt-2 pb-1" : ""}`}>
                              <div className="flex items-center gap-3 text-xs">
                                <span className={`w-2 h-2 rounded-full shrink-0 ${
                                  exec.status === "completed" ? "bg-green-500"
                                  : exec.status === "failed"    ? "bg-red-500"
                                  : "bg-yellow-500"
                                }`} />
                                {isLatest && (
                                  <span className="bg-zinc-600 text-zinc-300 text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0">LATEST</span>
                                )}
                                <span className="text-zinc-300 font-mono">
                                  {new Date(exec.created_at).toLocaleString()}
                                </span>
                                {durationS !== null && (
                                  <span className="text-zinc-500">{durationS}s</span>
                                )}
                                {/* Browser */}
                                <span className="text-zinc-400 shrink-0">
                                  {exec.browser === "firefox" ? "🦊 Firefox"
                                    : exec.browser === "webkit" ? "🧭 Safari"
                                    : exec.browser === "msedge" ? "🟦 Edge"
                                    : exec.browser === "chrome"  ? "🌐 Chrome"
                                    : "🔵 Chromium"}
                                </span>
                                {/* Execution status */}
                                <span className={`font-semibold ${
                                  exec.status === "completed" ? "text-green-400"
                                  : exec.status === "failed"    ? "text-red-400"
                                  : "text-yellow-400"
                                }`}>
                                  {exec.status === "completed" ? "Completed"
                                    : exec.status === "failed"  ? "Failed"
                                    : exec.status === "running" ? "Running"
                                    : "Queued"}
                                </span>
                                {/* Test result badge */}
                                <span className={`px-2 py-0.5 rounded-full font-bold text-white ${
                                  exec.status === "completed" ? "bg-green-600"
                                  : exec.status === "failed"    ? "bg-red-600"
                                  : "bg-zinc-600"
                                }`}>
                                  {exec.status === "completed" ? "Pass"
                                    : exec.status === "failed"  ? "Fail"
                                    : "—"}
                                </span>
                                <button
                                  onClick={() =>
                                    setViewingExecId(v => ({ ...v, [t.id]: isViewing ? null : exec.id }))
                                  }
                                  className={`ml-auto shrink-0 px-3 py-1 rounded-md text-xs font-semibold border transition-colors ${
                                    isViewing
                                      ? "border-zinc-500 bg-zinc-700 text-white hover:bg-zinc-600"
                                      : "border-blue-500 bg-blue-600 text-white hover:bg-blue-500"
                                  }`}
                                >
                                  {isViewing ? "Close" : "View Steps"}
                                </button>
                              </div>
                              {isViewing && (
                                <div className="border border-zinc-700 rounded-xl p-4 bg-zinc-900">
                                  <ExecutionTimeline executionId={exec.id} />
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}


              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
