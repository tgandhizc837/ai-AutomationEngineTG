"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/providers/AuthProvider";
import { ProjectAPI, Project } from "@/modules/project/project.api";

// ── tiny inline form state ────────────────────────────────────────
interface CreateForm {
  name: string;
  base_url: string;
}

const EMPTY: CreateForm = { name: "", base_url: "" };

export default function ProjectsPage() {
  const { user } = useAuth();
  const router   = useRouter();

  const [projects,   setProjects]   = useState<Project[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [showForm,   setShowForm]   = useState(false);
  const [form,       setForm]       = useState<CreateForm>(EMPTY);
  const [saving,     setSaving]     = useState(false);
  const [formError,  setFormError]  = useState<string | null>(null);

  // ── Load projects ──────────────────────────────────────────────
  const load = async () => {
    if (!user?.workspaceId) return;
    setLoading(true);
    try {
      const data = await ProjectAPI.list(user.workspaceId);
      setProjects(data);
    } catch {
      // ignore — workspace may not exist yet
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [user?.workspaceId]);

  // ── Create project ─────────────────────────────────────────────
  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user?.workspaceId) {
      setFormError("No workspace ID found. Restart the backend then reload this page.");
      console.error("[Projects] workspaceId missing — user:", user);
      return;
    }

    setFormError(null);
    setSaving(true);
    try {
      console.log("[Projects] POST /projects:", { workspace_id: user.workspaceId, name: form.name.trim() });
      const created = await ProjectAPI.create({
        workspace_id: user.workspaceId,
        name:         form.name.trim(),
        base_url:     form.base_url.trim() || undefined,
      });
      console.log("[Projects] Created project:", created);
      setForm(EMPTY);
      setShowForm(false);
      await load();
    } catch (err: any) {
      console.error("[Projects] Create failed:", err);
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* ── Header ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-white">Projects</h1>
        <button
          onClick={() => { setShowForm(true); setFormError(null); }}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors"
        >
          + New Project
        </button>
      </div>

      {/* ── Session warning banner ── */}
      {!user?.workspaceId && (
        <div className="text-sm text-amber-300 bg-amber-950/40 border border-amber-700 rounded-lg px-4 py-3">
          ⚠️ <strong>Session not ready.</strong> Please restart the backend server and reload this page.
        </div>
      )}

      {/* ── Create form ── */}
      {showForm && (
        <div className="border border-zinc-700 rounded-xl bg-zinc-900 p-6 space-y-4 max-w-xl">
          <h2 className="text-lg font-semibold text-white">Create Project</h2>

          <form onSubmit={handleCreate} className="space-y-4">
            {/* Project name */}
            <div>
              <label className="block text-sm text-zinc-400 mb-1">
                Project name <span className="text-red-400">*</span>
              </label>
              <input
                required
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="My Web App"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Base URL */}
            <div>
              <label className="block text-sm text-zinc-400 mb-1">
                Base URL
                <span className="text-zinc-500 ml-1">(the app you want to test)</span>
              </label>
              <input
                type="url"
                value={form.base_url}
                onChange={(e) => setForm((f) => ({ ...f, base_url: e.target.value }))}
                placeholder="https://your-app.com"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {formError && (
              <p className="text-sm text-red-400 bg-red-950/40 border border-red-800 rounded-lg px-3 py-2">{formError}</p>
            )}

            <div className="flex gap-3">
              <button
                type="submit"
                disabled={saving || !user?.workspaceId}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-lg transition-colors"
              >
                {saving ? "Creating…" : "Create Project"}
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-4 py-2 bg-zinc-700 hover:bg-zinc-600 text-white text-sm font-semibold rounded-lg transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ── Project list ── */}
      {loading ? (
        <p className="text-zinc-500 text-sm animate-pulse">Loading projects…</p>
      ) : projects.length === 0 ? (
        <div className="border border-dashed border-zinc-700 rounded-xl p-12 text-center">
          <p className="text-zinc-500 text-sm mb-3">No projects yet.</p>
          <button
            onClick={() => setShowForm(true)}
            className="text-blue-400 hover:text-blue-300 text-sm underline"
          >
            Create your first project
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((p) => (
            <button
              key={p.id}
              onClick={() => router.push(`/dashboard/projects/${p.id}`)}
              className="text-left border border-zinc-700 hover:border-zinc-500 bg-zinc-900 hover:bg-zinc-800 rounded-xl p-5 transition-colors space-y-1"
            >
              <p className="text-white font-semibold text-sm">{p.name}</p>
              {p.base_url && (
                <p className="text-zinc-500 text-xs truncate">{p.base_url}</p>
              )}
              <p className="text-zinc-600 text-xs">
                {new Date(p.created_at).toLocaleDateString()}
              </p>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
