"use client";

import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/api";

interface Stats {
  total_executions: number;
  success_rate: number;
  avg_duration_ms: number | null;
  total_tokens: number;
  total_cost_usd: number;
}

function MetricCard({
  label,
  value,
  sub,
  color = "text-white",
}: {
  label: string;
  value: string;
  sub?: string;
  color?: string;
}) {
  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 flex flex-col gap-1">
      <p className="text-xs text-zinc-500 uppercase tracking-wide font-semibold">{label}</p>
      <p className={`text-3xl font-bold ${color}`}>{value}</p>
      {sub && <p className="text-xs text-zinc-500 mt-0.5">{sub}</p>}
    </div>
  );
}

function formatDuration(ms: number | null): string {
  if (ms === null) return "—";
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${(ms / 60000).toFixed(1)}m`;
}

function formatTokens(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return `${n}`;
}

export default function DashboardPage() {
  const [stats, setStats]     = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiFetch<Stats>("/executions/stats");
      setStats(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const successColor =
    !stats ? "text-white"
    : stats.success_rate >= 80 ? "text-green-400"
    : stats.success_rate >= 50 ? "text-yellow-400"
    : "text-red-400";

  return (
    <div className="p-6 space-y-8">

      {/* ── Header ── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-white">Dashboard</h1>
          <p className="text-sm text-zinc-500 mt-0.5">Overview of your test automation activity</p>
        </div>
        <button
          onClick={load}
          disabled={loading}
          className="px-3 py-1.5 text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-zinc-300 rounded-lg transition-colors"
        >
          {loading ? "Refreshing…" : "↻ Refresh"}
        </button>
      </div>

      {/* ── Error ── */}
      {error && (
        <div className="text-sm text-red-400 bg-red-950/40 border border-red-800 rounded-xl px-4 py-3">
          {error}
        </div>
      )}

      {/* ── Metric cards ── */}
      {loading && !stats ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 animate-pulse h-24" />
          ))}
        </div>
      ) : stats ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <MetricCard
            label="Executions"
            value={`${stats.total_executions}`}
            sub="total test runs"
          />
          <MetricCard
            label="Success Rate"
            value={`${stats.success_rate}%`}
            sub={`${Math.round((stats.success_rate / 100) * stats.total_executions)} passed`}
            color={successColor}
          />
          <MetricCard
            label="Avg Duration"
            value={formatDuration(stats.avg_duration_ms)}
            sub="per execution"
          />
          <MetricCard
            label="Token Usage"
            value={formatTokens(stats.total_tokens)}
            sub={`$${stats.total_cost_usd.toFixed(4)} total cost`}
            color="text-blue-400"
          />
        </div>
      ) : null}

    </div>
  );
}
