import Link from "next/link";

const FEATURES = [
  {
    icon: "🤖",
    title: "AI-Powered Test Resolution",
    desc: "Natural language Gherkin steps are resolved to real browser actions by GPT-4o-mini — no selectors to write.",
  },
  {
    icon: "🔵",
    title: "Multi-Browser Support",
    desc: "Run tests on Chromium, Chrome, Edge, Firefox, or WebKit (Safari) from a single click.",
  },
  {
    icon: "🩹",
    title: "Self-Healing Tests",
    desc: "When a selector breaks, the healing agent finds the right element automatically using vector similarity.",
  },
  {
    icon: "📊",
    title: "Live Execution Streaming",
    desc: "Watch step-by-step results in real time as your test runs — no page refresh needed.",
  },
  {
    icon: "🎥",
    title: "Video Recording",
    desc: "Every run is recorded. Replay exactly what happened in the browser after the test completes.",
  },
  {
    icon: "💾",
    title: "LLM Cache & Cost Control",
    desc: "Responses are cached after the first run. Repeated tests cost zero tokens.",
  },
];

export default function HomePage() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white flex flex-col">

      {/* ── Nav ── */}
      <header className="border-b border-zinc-800 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🤖</span>
          <span className="text-lg font-bold tracking-tight">AI-Powered Test Automation</span>
        </div>
        <div className="flex items-center gap-3">
          <Link
            href="/login"
            className="px-4 py-1.5 text-sm text-zinc-300 hover:text-white transition-colors"
          >
            Log in
          </Link>
          <Link
            href="/signup"
            className="px-4 py-1.5 text-sm font-semibold bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
          >
            Get started free
          </Link>
        </div>
      </header>

      {/* ── Hero ── */}
      <main className="flex-1 flex flex-col items-center justify-center text-center px-6 py-20 space-y-6 max-w-3xl mx-auto">
        <span className="text-xs font-semibold uppercase tracking-widest text-blue-400 bg-blue-950/40 border border-blue-800 px-3 py-1 rounded-full">
          AI-Powered Test Automation
        </span>

        <h1 className="text-5xl font-extrabold leading-tight tracking-tight">
          Write tests in plain English.<br />
          <span className="text-blue-400">Let AI do the rest.</span>
        </h1>

        <p className="text-zinc-400 text-lg leading-relaxed max-w-xl">
          AI-Powered Test Automation turns your Gherkin scenarios into fully automated browser tests — no selectors, no scripts, no maintenance.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
          <Link
            href="/signup"
            className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl text-sm transition-colors"
          >
            Start for free →
          </Link>
          <Link
            href="/login"
            className="px-6 py-3 border border-zinc-700 hover:border-zinc-500 text-zinc-300 hover:text-white font-semibold rounded-xl text-sm transition-colors"
          >
            Log in to dashboard
          </Link>
        </div>
      </main>

      {/* ── Features ── */}
      <section className="border-t border-zinc-800 px-6 py-16">
        <div className="max-w-5xl mx-auto">
          <p className="text-center text-xs uppercase tracking-widest text-zinc-500 font-semibold mb-10">
            What's inside
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {FEATURES.map((f) => (
              <div
                key={f.title}
                className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-2 hover:border-zinc-700 transition-colors"
              >
                <div className="text-2xl">{f.icon}</div>
                <p className="font-semibold text-white text-sm">{f.title}</p>
                <p className="text-zinc-500 text-xs leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="border-t border-zinc-800 px-6 py-5 text-center text-xs text-zinc-600">
        © {new Date().getFullYear()} AI-Powered Test Automation. All rights reserved.
      </footer>

    </div>
  );
}
