"use client";

import { useEffect, useState } from "react";

// ── Types matching the SSE payload from the backend ──────────────
interface ExecutionStep {
  id: string;
  name: string;
  status: "pending" | "passed" | "failed" | "running";
  logs: string[];
}

interface ExecutionState {
  id: string;
  status: "queued" | "running" | "completed" | "failed" | "cancelled";
  steps: ExecutionStep[];
}

const STATUS_COLOR: Record<string, string> = {
  queued:    "#888",
  running:   "#2563eb",
  completed: "#16a34a",
  failed:    "#dc2626",
  cancelled: "#9ca3af",
  pending:   "#888",
  passed:    "#16a34a",
};

export default function ExecutionPage({
  params,
}: {
  params: { id: string };
}) {
  const [execution, setExecution] = useState<ExecutionState | null>(null);
  const [error, setError]         = useState<string | null>(null);

  useEffect(() => {
    const url = `/api/executions/${params.id}/stream`;
    const evt = new EventSource(url);

    evt.onmessage = (event) => {
      try {
        setExecution(JSON.parse(event.data));
      } catch {
        // ignore malformed frame
      }
    };

    evt.onerror = () => {
      setError("Lost connection to execution stream.");
      evt.close();
    };

    return () => evt.close();
  }, [params.id]);

  if (error) {
    return (
      <div style={{ padding: 20, color: "#dc2626" }}>
        {error}
      </div>
    );
  }

  if (!execution) {
    return <div style={{ padding: 20, color: "#888" }}>Connecting…</div>;
  }

  const statusColor = STATUS_COLOR[execution.status] ?? "#888";

  return (
    <div style={{ padding: 24, fontFamily: "monospace", maxWidth: 800 }}>
      <h1 style={{ fontSize: 18, marginBottom: 4 }}>
        Execution
      </h1>
      <p style={{ fontSize: 12, color: "#888", marginBottom: 16 }}>
        {execution.id}
      </p>

      {/* ── Status badge ── */}
      <span
        style={{
          display:      "inline-block",
          padding:      "4px 12px",
          borderRadius: 999,
          background:   statusColor,
          color:        "#fff",
          fontWeight:   600,
          fontSize:     13,
          marginBottom: 24,
          textTransform: "uppercase",
        }}
      >
        {execution.status}
      </span>

      {/* ── Step list ── */}
      <div>
        {execution.steps.length === 0 && (
          <p style={{ color: "#888" }}>Waiting for steps…</p>
        )}

        {execution.steps.map((step, i) => {
          const stepColor = STATUS_COLOR[step.status] ?? "#888";
          return (
            <div
              key={step.id}
              style={{
                marginBottom:  12,
                padding:       12,
                borderRadius:  6,
                border:        `1px solid ${stepColor}33`,
                background:    `${stepColor}0d`,
              }}
            >
              <div
                style={{
                  display:        "flex",
                  alignItems:     "center",
                  gap:            8,
                  marginBottom:   step.logs.length ? 6 : 0,
                }}
              >
                <span style={{ color: "#888", fontSize: 12, minWidth: 24 }}>
                  {i + 1}.
                </span>
                <span style={{ flex: 1, fontSize: 14 }}>{step.name}</span>
                <span
                  style={{
                    fontSize:     11,
                    fontWeight:   600,
                    color:        stepColor,
                    textTransform: "uppercase",
                  }}
                >
                  {step.status}
                </span>
              </div>

              {step.logs.map((log, li) => (
                <div
                  key={li}
                  style={{
                    fontSize:     11,
                    color:        "#dc2626",
                    paddingLeft:  32,
                    marginTop:    2,
                    wordBreak:    "break-word",
                  }}
                >
                  {log}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}
