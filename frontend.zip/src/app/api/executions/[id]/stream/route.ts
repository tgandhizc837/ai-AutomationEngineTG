import { NextRequest } from "next/server";

const BACKEND  = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";
const POLL_MS  = 1500;
const TERMINAL = new Set(["completed", "failed", "cancelled"]);

/**
 * GET /api/executions/:id/stream
 *
 * Implements SSE directly in Next.js by polling the two Fastify REST endpoints:
 *   GET /executions/:id
 *   GET /executions/:id/steps
 *
 * This avoids Node.js fetch buffering issues that occur when trying to proxy
 * a Fastify SSE stream.  Cookies are forwarded on every poll so the Fastify
 * auth middleware accepts the request.
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const cookieHeader = request.headers.get("cookie") ?? "";
  const id = params.id;

  const headers = {
    cookie: cookieHeader,
    "Content-Type": "application/json",
    Accept: "application/json",
  };

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      const send = (data: unknown) => {
        try {
          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify(data)}\n\n`)
          );
        } catch {
          // controller already closed — ignore
        }
      };

      const poll = async (): Promise<boolean> => {
        try {
          const [execRes, stepsRes] = await Promise.all([
            fetch(`${BACKEND}/executions/${id}`,       { headers }),
            fetch(`${BACKEND}/executions/${id}/steps`, { headers }),
          ]);

          if (!execRes.ok) {
            // auth failure or execution not found
            send({ error: `Backend returned ${execRes.status}` });
            return true; // stop polling
          }

          const exec  = await execRes.json();
          const steps = stepsRes.ok ? await stepsRes.json() : [];

          send({
            id:        exec.id,
            status:    exec.status,
            video_url: exec.result?.video_url ?? null,
            steps:  (steps as any[]).map((s) => ({
              id:     s.id,
              name:   s.action,
              status: s.status,
              logs:   s.error ? [s.error] : [],
            })),
          });

          return TERMINAL.has(exec.status); // true = stop
        } catch {
          return true; // network error — stop
        }
      };

      // ── Send first snapshot immediately ──
      const done = await poll();
      if (done) {
        // Signal intentional close so the client doesn't show an error
        try {
          controller.enqueue(encoder.encode(`event: done\ndata: {}\n\n`));
          controller.close();
        } catch { /* ignore */ }
        return;
      }

      // ── Poll every POLL_MS ──
      const timer = setInterval(async () => {
        const finished = await poll();
        if (finished) {
          clearInterval(timer);
          // Signal intentional close before closing the stream
          try {
            controller.enqueue(encoder.encode(`event: done\ndata: {}\n\n`));
            controller.close();
          } catch { /* ignore */ }
        }
      }, POLL_MS);

      // ── Clean up if client disconnects ──
      request.signal.addEventListener("abort", () => {
        clearInterval(timer);
        try { controller.close(); } catch { /* ignore */ }
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type":  "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection:      "keep-alive",
      "X-Accel-Buffering": "no", // disables nginx buffering if behind a proxy
    },
  });
}

