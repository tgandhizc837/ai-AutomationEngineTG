import { apiFetch } from "@/lib/api";

export interface Project {
  id: string;
  workspace_id: string;
  name: string;
  base_url: string | null;
  created_at: string;
}

export interface Test {
  id: string;
  project_id: string;
  name: string;
  gherkin: string;
  created_at: string;
}

export const ProjectAPI = {
  list: (workspaceId: string): Promise<Project[]> =>
    apiFetch(`/projects?workspace_id=${workspaceId}`),

  create: (payload: {
    workspace_id: string;
    name: string;
    base_url?: string;
  }): Promise<Project> =>
    apiFetch("/projects", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  listTests: (projectId: string): Promise<Test[]> =>
    apiFetch(`/tests?project_id=${projectId}`),

  createTest: (payload: {
    project_id: string;
    name: string;
    gherkin: string;
  }): Promise<Test> =>
    apiFetch("/tests", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
};
