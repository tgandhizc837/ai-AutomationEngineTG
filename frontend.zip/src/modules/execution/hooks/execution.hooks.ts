import { useEffect, useRef, useState } from "react";
import { ExecutionStep, ExecutionStatus } from "../types/execution.types";

const BACKEND = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

export interface LiveExecution {
  id: string;
  status: ExecutionStatus;
  video_url: string | null;
  steps: Array<{
    id: string;
    name: string;
    status: ExecutionStep["status"];
    logs: string[];
  }>;
}

const TERMINAL = new Set(["completed", "failed", "cancelled"]);

export function useExecutionStream(
  executionId: string | null,
  options?: { onTerminal?: (status: ExecutionStatus) => void }
): {
  execution: LiveExecution | null;
  error: string | null;
} {
  const [execution, setExecution] = useState<LiveExecution | null>(null);
  const [error, setError]         = useState<string | null>(null);
  const terminalRef = useRef(false);
  const onTerminalRef = useRef(options?.onTerminal);
  onTerminalRef.current = options?.onTerminal;

  useEffect(() => {
    if (!executionId) return;

    terminalRef.current = false;
    setExecution(null);
    setError(null);

    const evt = new EventSource(`/api/executions/${executionId}/stream`);

    evt.onmessage = (e) => {
      try {
        const data: LiveExecution = JSON.parse(e.data);
        setExecution(data);
        if (TERMINAL.has(data.status)) {
          terminalRef.current = true;
        }
      } catch {
        // ignore malformed frame
      }
    };

    evt.addEventListener("done", () => {
      terminalRef.current = true;
      evt.close();

      // Notify caller (e.g. to refresh history list)
      setExecution(prev => {
        if (prev) onTerminalRef.current?.(prev.status);
        return prev;
      });

      // Video is saved in the backend finally-block AFTER the stream closes.
      // Wait 3 s then do one extra fetch to pick up video_url.
      setTimeout(async () => {
        try {
          const res = await fetch(`${BACKEND}/executions/${executionId}`, {
            credentials: "include",
          });
          if (!res.ok) return;
          const exec = await res.json();
          if (exec?.result?.video_url) {
            setExecution(prev =>
              prev ? { ...prev, video_url: exec.result.video_url } : prev
            );
          }
        } catch {
          // non-fatal
        }
      }, 3000);
    });

    evt.onerror = () => {
      evt.close();
      if (!terminalRef.current) {
        setError("Lost connection to execution stream.");
      }
    };

    return () => evt.close();
  }, [executionId]);

  return { execution, error };
}
