// ==============================
// 🔹 Execution Status Enum
// ==============================
export type ExecutionStatus =
  | "queued"
  | "running"
  | "completed"
  | "failed";

// ==============================
// 🔹 Execution Entity
// ==============================
export interface Execution {
  id: string;

  test_id: string;
  workspace_id?: string;

  status: ExecutionStatus;

  result?: any;

  started_at?: string;
  completed_at?: string;
  created_at: string;
  updated_at?: string;
}

// ==============================
// 🔹 Execution Step Status
// ==============================
export type ExecutionStepStatus =
  | "pending"
  | "running"
  | "passed"
  | "failed"
  | "healed";

// ==============================
// 🔹 Execution Step Entity
// ==============================
export interface ExecutionStep {
  id: string;

  execution_id: string;
  test_id: string;

  step_index: number;

  action: string; // raw step text
  selector?: string;

  status: ExecutionStepStatus;

  duration_ms?: number;

  error?: string;

  healed_selector?: string;

  created_at: string;
}

// ==============================
// 🔹 API Request Types
// ==============================
export interface CreateExecutionRequest {
  test_id: string;
}

// ==============================
// 🔹 API Response Types
// ==============================
export interface CreateExecutionResponse {
  execution: Execution;
}

// ==============================
// 🔹 Step Runner Result
// ==============================
export interface StepRunResult {
  success: boolean;
  healed: boolean;
  error?: string;
}

// ==============================
// 🔹 Execution Detail (UI use)
// ==============================
export interface ExecutionDetail {
  execution: Execution;
  steps: ExecutionStep[];
}

// ==============================
// 🔹 Planning Output
// ==============================
export interface PlanResult {
  steps: string[];
}