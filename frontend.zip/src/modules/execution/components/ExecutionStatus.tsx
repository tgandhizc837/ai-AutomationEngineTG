"use client";

import { ExecutionStatus as TStatus } from "../types/execution.types";

const COLOR: Record<TStatus, string> = {
  queued:    "bg-gray-500",
  running:   "bg-blue-600 animate-pulse",
  completed: "bg-green-600",
  failed:    "bg-red-600",
};

const LABEL: Record<TStatus, string> = {
  queued:    "Queued",
  running:   "Running…",
  completed: "Completed",
  failed:    "Failed",
};

export default function ExecutionStatus({ status }: { status: TStatus }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold text-white ${COLOR[status]}`}
    >
      {status === "running" && (
        <span className="w-2 h-2 rounded-full bg-white opacity-80 animate-ping inline-block" />
      )}
      {LABEL[status]}
    </span>
  );
}
