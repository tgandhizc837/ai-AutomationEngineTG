"use client";

import { useExecutionStream } from "../hooks/execution.hooks";
import ExecutionStatus from "./ExecutionStatus";
import ExecutionSteps  from "./ExecutionSteps";
import { ExecutionStatus as TStatus } from "../types/execution.types";

interface Props {
  executionId: string;
  onTerminal?: (status: TStatus) => void;
}

/**
 * ExecutionTimeline — live view of a single execution.
 *
 * Subscribes to SSE via /api/executions/:id/stream (Next.js proxy → Fastify).
 * Renders real-time status badge + step-by-step results as they arrive.
 */
export default function ExecutionTimeline({ executionId, onTerminal }: Props) {
  const { execution, error } = useExecutionStream(executionId, { onTerminal });

  if (error) {
    return (
      <div className="rounded-lg border border-red-700 bg-red-950/40 p-4 text-sm text-red-400">
        {error}
      </div>
    );
  }

  if (!execution) {
    return (
      <div className="text-sm text-gray-500 animate-pulse py-4">
        Connecting to execution stream…
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* ── Status row ── */}
      <div className="flex items-center gap-3">
        <span className="text-sm text-gray-400">Status</span>
        <ExecutionStatus status={execution.status} />
      </div>

      {/* ── Step list ── */}
      <ExecutionSteps steps={execution.steps} />

      {/* ── Summary when done ── */}
      {(execution.status === "completed" || execution.status === "failed") && (
        <div
          className={`text-sm font-semibold py-2 ${
            execution.status === "completed"
              ? "text-green-400"
              : "text-red-400"
          }`}
        >
          {execution.status === "completed"
            ? `✓ All ${execution.steps.length} step(s) passed`
            : `✗ Test failed — ${
                execution.steps.filter((s) => s.status === "failed").length
              } step(s) failed`}
        </div>
      )}

      {/* ── Video replay ── */}
      {execution.video_url && (
        <div className="mt-4 space-y-2">
          <p className="text-xs text-zinc-400 font-semibold uppercase tracking-wide">
            🎬 Test Recording
          </p>
          <video
            src={`http://localhost:4000${execution.video_url}`}
            controls
            className="w-full rounded-xl border border-zinc-700 bg-black max-h-96"
          />
        </div>
      )}
    </div>
  );
}
