"use client";

import { LiveExecution } from "../hooks/execution.hooks";

type Step = LiveExecution["steps"][number];

const STEP_COLOR: Record<Step["status"], string> = {
  pending: "border-gray-600 bg-gray-800/40 text-gray-400",
  running: "border-blue-500 bg-blue-900/30 text-blue-300",
  passed:  "border-green-500 bg-green-900/30 text-green-400",
  failed:  "border-red-500  bg-red-900/30  text-red-400",
  healed:  "border-yellow-500 bg-yellow-900/30 text-yellow-400",
};

const STEP_ICON: Record<Step["status"], string> = {
  pending: "○",
  running: "◉",
  passed:  "✓",
  failed:  "✗",
  healed:  "⟳",
};

const STEP_LABEL: Record<Step["status"], string> = {
  pending: "Pending",
  running: "Running",
  passed:  "Pass",
  failed:  "Fail",
  healed:  "Healed",
};

export default function ExecutionSteps({ steps }: { steps: Step[] }) {
  if (steps.length === 0) {
    return (
      <p className="text-sm text-gray-500 py-4">
        Waiting for steps to run…
      </p>
    );
  }

  return (
    <div className="space-y-2">
      {steps.map((step, i) => {
        const style = STEP_COLOR[step.status] ?? STEP_COLOR.pending;
        const icon  = STEP_ICON[step.status]  ?? "○";

        return (
          <div
            key={step.id}
            className={`flex flex-col gap-1 border rounded-lg px-4 py-3 text-sm font-mono transition-colors ${style}`}
          >
            <div className="flex items-center gap-3">
              <span className="text-base w-5 text-center">{icon}</span>
              <span className="text-gray-400 w-6 shrink-0">{i + 1}.</span>
              <span className="flex-1 text-white">{step.name}</span>
              <span className="text-xs font-semibold uppercase opacity-80">
                {STEP_LABEL[step.status] ?? step.status}
              </span>
            </div>

            {step.logs.map((log, li) => (
              <div
                key={li}
                className="ml-14 text-xs text-red-400 break-words"
              >
                {log}
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
}
