"use client";

import { useState } from "react";
import { ExecutionAPI, BrowserChoice } from "@/modules/execution/api/execution.api";
import ExecutionTimeline from "./ExecutionTimeline";
import { ExecutionStatus as TStatus } from "../types/execution.types";

// ── Browser options ───────────────────────────────────────────────
const BROWSER_OPTIONS: { value: BrowserChoice; label: string; icon: string; note?: string }[] = [
  { value: "chromium", label: "Chromium",        icon: "🔵", note: "bundled"       },
  { value: "chrome",   label: "Chrome",           icon: "🌐", note: "system"        },
  { value: "msedge",   label: "Microsoft Edge",   icon: "🟦", note: "system"        },
  { value: "firefox",  label: "Firefox",          icon: "🦊", note: "bundled"       },
  { value: "webkit",   label: "WebKit (Safari)",  icon: "🧭", note: "bundled"       },
];

interface Props {
  testId: string;
  projectId: string;
  /** If provided, shows the last known run result immediately on mount */
  initialExecutionId?: string | null;
  /** Called with the new executionId when a run starts */
  onRunStarted?: (executionId: string) => void;
  /** Called when the active run reaches a terminal status */
  onTerminal?: (status: TStatus) => void;
}

export default function RunTestButton({ testId, projectId, initialExecutionId, onRunStarted, onTerminal }: Props) {
  const [executionId, setExecutionId] = useState<string | null>(initialExecutionId ?? null);
  const [loading, setLoading]         = useState(false);
  const [runError, setRunError]       = useState<string | null>(null);

  // Browser / headless state
  const [browser,  setBrowser]  = useState<BrowserChoice>("chromium");
  const [headless, setHeadless] = useState(true);

  const handleRun = async () => {
    setLoading(true);
    setRunError(null);
    setExecutionId(null);

    try {
      const res = await ExecutionAPI.runTest(testId, projectId, browser, headless);
      setExecutionId(res.id);
      onRunStarted?.(res.id);
    } catch (err: any) {
      setRunError(err.message || "Failed to start test");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">

      {/* ── Browser + headless controls ── */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Browser picker */}
        <div className="flex flex-col gap-1 min-w-[180px]">
          <label className="text-xs text-zinc-400 font-semibold uppercase tracking-wide">Browser</label>
          <select
            value={browser}
            onChange={(e) => setBrowser(e.target.value as BrowserChoice)}
            disabled={loading}
            className="bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {BROWSER_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.icon} {opt.label}{opt.note ? ` (${opt.note})` : ""}
              </option>
            ))}
          </select>
        </div>

        {/* Headless toggle */}
        <div className="flex flex-col gap-1">
          <label className="text-xs text-zinc-400 font-semibold uppercase tracking-wide">Mode</label>
          <button
            type="button"
            disabled={loading}
            onClick={() => setHeadless((h) => !h)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-semibold transition-colors disabled:opacity-50 ${
              headless
                ? "border-zinc-600 bg-zinc-800 text-zinc-300 hover:border-zinc-500"
                : "border-amber-500 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
            }`}
          >
            {headless ? (
              <><span>🖥</span> Headless</>
            ) : (
              <><span>👁</span> Headed</>
            )}
          </button>
          {!headless && (
            <p className="text-xs text-amber-500/80 max-w-[180px]">
              Browser window opens on the server machine
            </p>
          )}
        </div>
      </div>

      {/* ── Trigger button ── */}
      <button
        onClick={handleRun}
        disabled={loading}
        className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-semibold transition-colors"
      >
        {loading ? (
          <>
            <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            Starting…
          </>
        ) : executionId ? (
          "↻ Run Again"
        ) : (
          "▶ Run Test"
        )}
      </button>

      {/* ── Launch error ── */}
      {runError && (
        <p className="text-sm text-red-400">{runError}</p>
      )}

      {/* ── Live / last results ── */}
      {executionId && (
        <div className="mt-2 border border-zinc-700 rounded-xl p-4 bg-zinc-900">
          <ExecutionTimeline executionId={executionId} onTerminal={onTerminal} />
        </div>
      )}
    </div>
  );
}
