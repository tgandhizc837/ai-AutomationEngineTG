import { apiFetch } from "@/lib/api";

export type BrowserChoice = "chromium" | "firefox" | "webkit" | "chrome" | "msedge";

export const ExecutionAPI = {
  runTest: (testId: string, projectId: string, browser: BrowserChoice = "chromium", headless: boolean = true) =>
    apiFetch("/executions", {
      method: "POST",
      body: JSON.stringify({ test_id: testId, project_id: projectId, browser, headless }),
    }),

  getExecution: (id: string) =>
    apiFetch(`/executions/${id}`),

  listByTest: (testId: string) =>
    apiFetch(`/executions?test_id=${testId}`),

  listAll: () =>
    apiFetch(`/executions/all`),
};