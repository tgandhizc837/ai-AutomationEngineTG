const BASE_URL =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

// ==============================
// 🔹 Core API Fetch Wrapper
// ==============================
export async function apiFetch<T = any>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    credentials: "include", // 🔥 required for auth cookies
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });

  let data: any = null;

  try {
    data = await res.json();
  } catch {
    // ignore JSON parse error
  }

  if (!res.ok) {
    console.error("❌ API Error:", data);
    throw new Error(
      data?.message || data?.error || `API Error: ${res.status}`
    );
  }

  return data;
}

// ==============================
// 🔹 Execution APIs
// ==============================

// ✅ FINAL FIXED VERSION
export async function createExecution(
  testId: string,
  projectId: string
) {
  console.log("🚀 Creating execution:", { testId, projectId });

  return apiFetch("/executions", {
    method: "POST",
    body: JSON.stringify({
     test_id :testId,     // ✅ correct key
      project_id: projectId,  // ✅ REQUIRED
    }),
  });
}

export async function getExecutions() {
  return apiFetch("/executions", {
    method: "GET",
  });
}

export async function getExecutionById(executionId: string) {
  return apiFetch(`/executions/${executionId}`, {
    method: "GET",
  });
}