// src/queue/executionQueue.ts

import { Queue, Worker } from "bullmq";
import { bullmqConnection } from "../config/bullmq";
import { ExecutionOrchestrator } from "../orchestration/ExecutionOrchestrator";

// ✅ Queue

export const executionQueue = new Queue("execution-jobs", {
  connection: {
    host: "127.0.0.1",
    port: 6379,
  },
});
// ✅ Worker starter
export function startWorker() {
  console.log("🧠 BACKEND WORKER STARTED");

  const worker = new Worker(
    "execution-jobs",
    async (job) => {
      console.log("🔥 JOB RECEIVED IN BACKEND:", job.name, job.data);

      if (job.name === "run-test") {
        const { executionId, browser = "chromium", headless = true } = job.data;

        if (!executionId) throw new Error("executionId missing");

        await ExecutionOrchestrator.run(executionId, browser, headless);
      }
    },
    {
      connection: bullmqConnection,
      concurrency: 2,
    }
  );

  worker.on("failed", (job, err) => {
    console.error(`❌ Job ${job?.id} failed:`, err.message);
  });

  worker.on("completed", (job) => {
    console.log(`✅ Job ${job.id} completed`);
  });

  return worker;
}