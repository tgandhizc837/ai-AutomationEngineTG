import { Page } from "playwright";
import { ResolutionAgent } from "../agents/ResolutionAgent.js";
import { HealingAgent } from "../agents/HealingAgent.js";
import { ExecutionStepRepo } from "../repositories/ExecutionStepRepo.js";
import { LlmCacheRepo } from "../repositories/LlmCacheRepo.js";
import { LocatorMemoryRepo } from "../repositories/LocatorMemoryRepo.js";

/**
 * Returns a compact, token-efficient snapshot of interactive elements.
 * ~95% fewer tokens than page.content() while preserving selector-relevant data.
 */
async function getTrimmedDom(page: Page): Promise<string> {
  return page.evaluate((): string => {
    const ATTRS = ['id','name','type','placeholder','aria-label','href','role','value','for','data-testid'];
    const selector = 'button,a[href],input,select,textarea,[role="button"],[role="link"],[role="menuitem"],[role="tab"],[aria-label],label,[data-testid]';
    const els = Array.from(document.querySelectorAll(selector)).slice(0, 120);
    return els.map(el => {
      const tag = el.tagName.toLowerCase();
      const text = (el.textContent ?? '').trim().replace(/\s+/g, ' ').slice(0, 80);
      const parts: string[] = [];
      for (const a of ATTRS) {
        const v = el.getAttribute(a);
        if (v) parts.push(`${a}="${v.slice(0, 60)}"`);
      }
      return `<${tag}${parts.length ? ' ' + parts.join(' ') : ''}>${text}</${tag}>`;
    }).join('\n');
  });
}

export interface StepRunInput {
  executionId: string;
  executionStepId: string;
  workspaceId: string;
  projectId: string;
  rawStep: string;
  page: Page;
}

export interface StepRunResult {
  success: boolean;
  healed: boolean;
  error?: string;
}

export class StepRunner {
  static async run(input: StepRunInput): Promise<StepRunResult> {
    const {
      executionId,
      executionStepId,
      workspaceId,
      projectId,
      rawStep,
      page,
    } = input;

    let resolvedAction: "click" | "type" | "assert" | undefined;
    let resolvedSelector: string | undefined;
    let resolvedValue: string | undefined;
    const cacheKey = LlmCacheRepo.makeKey(projectId, rawStep);
    const stepStart = Date.now();

    try {
      // Wait for page to be fully idle before reading DOM or acting
      await page.waitForLoadState("networkidle", { timeout: 15000 }).catch(() =>
        page.waitForLoadState("domcontentloaded").catch(() => {})
      );

      const domSnapshot = await getTrimmedDom(page);

      console.log(`🔍 [ResolutionAgent] Resolving: "${rawStep}"`);
      const resolution = await ResolutionAgent.resolve({
        workspaceId,
        projectId,
        executionId,
        stepText: rawStep,
        domSnapshot,
      });

      resolvedAction = resolution.action;
      resolvedSelector = resolution.selector;
      resolvedValue = resolution.value;

      console.log(`🎯 [ResolutionAgent] action=${resolvedAction} selector="${resolvedSelector}" confidence=${resolution.confidence}`);

      // Store cache IMMEDIATELY after LLM responds — before execute().
      // This means run 2+ never pays LLM cost even if execution fails.
      await LlmCacheRepo.store(cacheKey, {
        action: resolvedAction,
        selector: resolvedSelector,
        value: resolvedValue,
        confidence: resolution.confidence,
      });

      await this.execute(
        page,
        resolvedAction,
        resolvedSelector,
        resolvedValue
      );

      // ✅ Execution verified — mark as verified (resets fail_count to 0) + save to locator memory
      const duration = Date.now() - stepStart;
      await LlmCacheRepo.storeVerified(cacheKey, {
        action: resolvedAction,
        selector: resolvedSelector,
        value: resolvedValue,
        confidence: resolution.confidence,
      });
      LocatorMemoryRepo.remember(workspaceId, projectId, rawStep, resolvedSelector).catch(() => {});

      await (ExecutionStepRepo as any).markPassed(executionStepId, duration);
      console.log(`✅ Step passed in ${duration}ms — selector "${resolvedSelector}" verified+cached`);

      return { success: true, healed: false };
    } catch (initialError: any) {
      console.error(`❌ [StepRunner] Initial attempt failed: ${initialError.message?.slice(0, 200)}`);
      console.error(`   selector tried: "${resolvedSelector}" | action: ${resolvedAction}`);

      // Timeout = selector fundamentally wrong (element doesn't exist) → invalidate immediately
      // Other errors = transient (networkidle, timing) → record failure (evicts after MAX_FAILURES)
      if (resolvedSelector) {
        const isTimeout = initialError.message?.includes("Timeout") || initialError.message?.includes("timeout");
        if (isTimeout) {
          console.warn(`⏱️  [StepRunner] Timeout detected — immediately invalidating cache for "${rawStep}"`);
          LlmCacheRepo.invalidate(cacheKey).catch(() => {});
        } else {
          LlmCacheRepo.recordFailure(cacheKey).catch(() => {});
        }
      }

      try {
        if (!resolvedSelector || !resolvedAction) {
          throw new Error(
            `Resolution failed before execution: ${initialError.message}`
          );
        }

        const domSnapshot = await getTrimmedDom(page);

        const healingResult = await HealingAgent.tryHeal({
          workspaceId,
          projectId,
          executionStepId,
          failedSelector: resolvedSelector,
          elementLabel: rawStep,
          domSnapshot,
          executionId,
        });

        if (!healingResult.success || !healingResult.newSelector) {
          throw new Error("Healing unsuccessful");
        }

        await this.execute(
          page,
          resolvedAction,
          healingResult.newSelector,
          resolvedValue
        );

        // ✅ Healed selector verified — overwrite cache with the working selector
        await LlmCacheRepo.storeVerified(cacheKey, {
          action: resolvedAction,
          selector: healingResult.newSelector,
          confidence: healingResult.confidence,
        });
        LocatorMemoryRepo.remember(workspaceId, projectId, rawStep, healingResult.newSelector!).catch(() => {});

        await (ExecutionStepRepo as any).markHealed(
          executionStepId,
          healingResult.newSelector
        );

        return { success: true, healed: true };
      } catch (healingError: any) {
        await (ExecutionStepRepo as any).markFailure(
          executionStepId,
          healingError.message
        );

        return {
          success: false,
          healed: false,
          error: healingError.message,
        };
      }
    }
  }

  private static async execute(
    page: Page,
    action: "click" | "type" | "assert",
    selector: string,
    value?: string
  ): Promise<void> {
    // Always wait for the page to settle before acting
    await page.waitForLoadState("domcontentloaded").catch(() => {});

    switch (action) {
      case "click": {
        // Try the LLM-resolved selector first (short timeout)
        const clicked = await page
          .locator(selector)
          .first()
          .click({ timeout: 8000 })
          .then(() => true)
          .catch(() => false);

        if (!clicked) {
          // Extract the human-readable text from selectors like:
          //   a:has-text("Login"), button:has-text("Login"), text=Login
          const textMatch =
            selector.match(/has-text\(["'](.+?)["']\)/) ||
            selector.match(/^text=(.+)$/i);
          const label = textMatch?.[1];

          if (label) {
            const fallbacks = [
              page.getByRole("button",   { name: label, exact: false }).first(),
              page.getByRole("link",     { name: label, exact: false }).first(),
              page.getByRole("menuitem", { name: label, exact: false }).first(),
              page.getByRole("tab",      { name: label, exact: false }).first(),
              page.getByText(label, { exact: false }).first(),
              page.locator(`[aria-label*="${label}" i]`).first(),
            ];

            for (const loc of fallbacks) {
              const visible = await loc.isVisible().catch(() => false);
              if (visible) {
                console.log(`🔄 [StepRunner] Selector fallback succeeded for "${label}"`);
                await loc.click();
                return;
              }
            }
          }

          // No fallback worked — re-run with full timeout to surface the real error
          await page.locator(selector).first().click();
        }
        break;
      }

      case "type":
        await page.fill(selector, value ?? "");
        break;

      case "assert": {
        // Wait for page to settle after any form submission
        await page.waitForLoadState("domcontentloaded").catch(() => {});

        // Extract the raw text to find from selectors like:
        //   div:has-text('some text')  →  some text
        //   text=some text             →  some text
        const textMatch =
          selector.match(/has-text\(['"](.+?)['"]\)/) ||
          selector.match(/^text=(.+)$/i);
        const searchText = textMatch?.[1] ?? selector;

        // Strategy 1: wait for the text to appear anywhere on the page (10s)
        const found = await page
          .waitForSelector(`text=${searchText}`, { timeout: 10000, state: "attached" })
          .then(() => true)
          .catch(() => false);

        if (found) {
          console.log(`✅ [StepRunner] Assert found text: "${searchText}"`);
          break;
        }

        // Strategy 2: check full page text content (handles hidden-but-present elements)
        const pageText = await page.evaluate(() => document.body.innerText).catch(() => "");
        if (pageText.toLowerCase().includes(searchText.toLowerCase())) {
          console.log(`✅ [StepRunner] Assert matched in page text: "${searchText}"`);
          break;
        }

        throw new Error(`Assertion failed: text not found on page: "${searchText}"`);
      }

      default:
        throw new Error(`Unsupported action: ${action}`);
    }
  }
}