import { chromium, firefox, webkit, Page, BrowserType } from "playwright";
import path from "path";
import fs from "fs";
import { ExecutionRepository } from "../modules/execution/execution.repository";
import { ExecutionStepRepo } from "../repositories/ExecutionStepRepo";
import { TestRepo } from "../repositories/TestRepo";
import { ProjectRepo } from "../repositories/ProjectRepo";
import { StepRunner } from "./StepRunner";
import { BudgetGuard } from "./BudgetGuard";
import { parseGherkin } from "../../../engine/src/cucumber/GherkinParser";
import { matchAndRun } from "../../../engine/src/steps/stepRunner";

// Recordings directory — served as static files
const RECORDINGS_DIR = path.resolve(process.cwd(), "recordings");
if (!fs.existsSync(RECORDINGS_DIR)) fs.mkdirSync(RECORDINGS_DIR, { recursive: true });

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function getErrorMessage(error: any): string {
  return (
    error?.response?.data?.error?.message ||
    error?.message ||
    "Unknown OpenAI error"
  );
}

function is429(error: any): boolean {
  return error?.status === 429 || error?.response?.status === 429;
}

function isQuotaExceeded(error: any): boolean {
  return getErrorMessage(error).toLowerCase().includes("exceeded your current quota");
}

async function withOpenAIRetry<T>(fn: () => Promise<T>, label: string): Promise<T> {
  const maxRetries = 3;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error: any) {
      if (!is429(error)) throw error;

      if (isQuotaExceeded(error)) {
        throw new Error(
          `OpenAI quota exceeded during ${label}. Update billing/limits or switch model.`
        );
      }

      if (attempt === maxRetries) throw error;

      // transient rate limit retry
      const backoffMs = 1000 * Math.pow(2, attempt - 1) + Math.floor(Math.random() * 250);
      console.warn(`⏳ 429 during ${label}, retrying in ${backoffMs}ms (attempt ${attempt}/${maxRetries})`);
      await sleep(backoffMs);
    }
  }

  throw new Error(`Failed ${label}`);
}

export class ExecutionOrchestrator {
  static async run(executionId: string, browserName: string = "chromium", headless: boolean = true) {
    console.log("🚀 Starting execution:", executionId);

    const executionRepo = new ExecutionRepository();
    // ✅ removed: const testRepo = new TestRepo() — TestRepo uses static methods

    // 🔍 Fetch execution
    const execution = await executionRepo.findById(executionId);
    if (!execution) throw new Error("Execution not found");

    console.log(`👤 Execution triggered by user: ${execution.user_id ?? execution.workspace_id}`);
    console.log(`🧪 Test ID: ${execution.test_id} | Workspace: ${execution.workspace_id}`);

    // 🔄 Mark running
    await executionRepo.markRunning(executionId);

    // 💰 Budget check
    await BudgetGuard.check(execution.workspace_id);

    // Resolve the Playwright browser engine
    let browserType: BrowserType;
    let launchOptions: Parameters<BrowserType["launch"]>[0] = { headless };

    if (browserName === "firefox") {
      browserType = firefox;
    } else if (browserName === "webkit") {
      browserType = webkit;
    } else if (browserName === "chrome") {
      browserType = chromium;
      launchOptions = { ...launchOptions, channel: "chrome" };
    } else if (browserName === "msedge") {
      browserType = chromium;
      launchOptions = { ...launchOptions, channel: "msedge" };
    } else {
      // default: bundled Chromium
      browserType = chromium;
    }

    console.log(`🌐 Launching ${browserName} (headless=${headless})`);
    const browser = await browserType.launch(launchOptions);

    // Each execution records to its own temp folder
    const videoDir = path.join(RECORDINGS_DIR, `tmp-${executionId}`);
    fs.mkdirSync(videoDir, { recursive: true });

    const context = await browser.newContext({
      recordVideo: {
        dir: videoDir,
        size: { width: 1280, height: 720 },
      },
    });
    const page: Page = await context.newPage();

    try {
      // =========================
      // 1️⃣ Load Test + Project
      // =========================

      // ✅ call statically — TestRepo.findById not testRepo.findById
      const test = await TestRepo.findById(execution.test_id);
      if (!test) throw new Error("Test not found");

      const project = await ProjectRepo.findById(test.project_id);
      if (!project) throw new Error("Project not found");

      // =========================
      // 2️⃣ Navigate
      // =========================

      if (project.base_url) {
        await page.goto(project.base_url, {
          waitUntil: "networkidle",
          timeout: 45000,
        });
      }

      // =========================
      // 3️⃣ Parse Gherkin Steps
      // =========================

      const steps = parseGherkin(test.gherkin);

      if (!steps || steps.length === 0) {
        throw new Error("No executable steps found in Gherkin");
      }

      console.log(`📋 Parsed ${steps.length} step(s) from Gherkin`);

      // =========================
      // 4️⃣ Execute Steps
      // =========================

      let stepIndex = 0;

      for (const stepText of steps) {
        stepIndex++;

        console.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        console.log(`➡️  Step ${stepIndex}/${steps.length}: ${stepText}`);

        const executionStep = await ExecutionStepRepo.create({
          executionId,
          testId: test.id,
          stepIndex,
          action: stepText,
          selector: "",
        });

        const stepStart = Date.now();

        // ── Primary: pattern-matched Playwright step ──────────────
        const patternResult = await matchAndRun(stepText, {
          page,
          baseUrl: project.base_url ?? "",
        });

        let result;

        if (patternResult.matched && !patternResult.error) {
          console.log(`✅ Step ${stepIndex} matched by regex StepDefinitions`);
          result = { success: true, healed: false };
        } else if (patternResult.matched && patternResult.error) {
          // Regex pattern matched but handler genuinely failed — do NOT waste tokens on LLM
          console.error(`❌ Step ${stepIndex} regex handler failed — not falling back to LLM`);
          console.error(`   Reason: ${patternResult.error}`);
          result = { success: false, healed: false, error: patternResult.error };
        } else {
          // ── Fallback: LLM-based resolution (no regex pattern matched) ──
          console.log(`🤖 Step ${stepIndex} unmatched by regex — falling back to LLM StepRunner`);
          result = await withOpenAIRetry(
            () =>
              StepRunner.run({
                executionId,
                executionStepId: executionStep.id,
                workspaceId: execution.workspace_id,
                projectId: project.id,
                rawStep: stepText,
                page,
              }),
            `StepRunner.run (step ${stepIndex})`
          );
        }

        if (!result.success) {
          const reason = result.error || "Step execution failed (no details)";
          console.error(`❌ Step ${stepIndex} FAILED: "${stepText}"`);
          console.error(`   Reason: ${reason}`);
          console.error(`   URL at failure: ${page.url()}`);

          await ExecutionStepRepo.markFailed(executionStep.id, reason);
          await executionRepo.markFailed(executionId);
          return;
        }

        const duration = Date.now() - stepStart;
        console.log(`✅ Step ${stepIndex} PASSED in ${duration}ms | URL: ${page.url()}`);

        await ExecutionStepRepo.markPassed(executionStep.id, duration);

        await page.waitForLoadState("networkidle").catch(() => {});
      }

      // =========================
      // ✅ Execution Completed
      // =========================

      console.log("✅ Execution completed");

      await executionRepo.markCompleted(executionId);

    } catch (error: any) {
      console.error("🔥 Execution error:", getErrorMessage(error));
      await executionRepo.markFailed(executionId);
      throw error;

    } finally {
      // ── Save video recording ─────────────────────────────────
      try {
        await page.close();   // must close page first to flush video
        await context.close();

        // Find the recorded .webm file in the temp dir
        const files = fs.readdirSync(videoDir).filter(f => f.endsWith(".webm"));
        if (files.length > 0) {
          const src = path.join(videoDir, files[0]);
          const dest = path.join(RECORDINGS_DIR, `${executionId}.webm`);
          fs.renameSync(src, dest);
          fs.rmdirSync(videoDir);

          // Save video URL into execution result
          await executionRepo.saveVideoPath(executionId, `/recordings/${executionId}.webm`);
          console.log(`🎥 Video saved: /recordings/${executionId}.webm`);
        }
      } catch (videoErr: any) {
        console.warn("⚠️ Could not save video:", videoErr.message);
      }

      await browser.close();
    }
  }
}