import { query } from "../config/db";

export class BudgetGuard {

  static async check(workspaceId: string) {

    // 1️⃣ Get workspace usage
    const rows = await query(
      `
      SELECT total_cost, budget_limit
      FROM workspace_usage
      WHERE workspace_id = $1
      `,
      [workspaceId]
    );

    const usage = rows[0];

    // 🟡 If no usage record → allow (MVP behavior)
    if (!usage) {
      console.log("⚠️ No usage record found, skipping budget check");
      return;
    }

    const totalCost = usage.total_cost || 0;
    const limit = usage.budget_limit || 0;

    // 2️⃣ Enforce budget
    if (limit > 0 && totalCost >= limit) {
      throw new Error("Budget exceeded for workspace");
    }

    console.log(`💰 Budget OK: ${totalCost}/${limit}`);
  }
}