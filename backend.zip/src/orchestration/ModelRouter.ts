export class ModelRouter {
  static route(task: "planning" | "resolution" | "healing") {
    switch (task) {
      case "planning":
        return "gpt-4o-mini";
      case "resolution":
        return "gpt-4o-mini";
      case "healing":
        return "gpt-4o-mini";
      default:
        return "gpt-4o-mini";
    }
  }
}