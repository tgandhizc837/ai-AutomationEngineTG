export type ExecutionStatus =
  | "pending"
  | "running"
  | "completed"
  | "failed";

export interface Execution {
  id: string;
  workspace_id: string;
  test_id: string;
  status: ExecutionStatus;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
}