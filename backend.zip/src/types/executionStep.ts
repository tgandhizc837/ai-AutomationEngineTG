export type StepStatus =
  | "pending"
  | "running"
  | "completed"
  | "failed";

export interface ExecutionStep {
  id: string;
  execution_id: string;
  order_index: number;
  raw_text: string;
  status: StepStatus;
  error_message: string | null;
  created_at: string;
}