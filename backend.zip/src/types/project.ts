export interface Project {
  id: string;
  workspace_id: string;
  name: string;
  base_url: string | null;
  created_at: string;
}

export interface CreateProjectInput {
  workspaceId: string;
  name: string;
  baseUrl?: string;
}