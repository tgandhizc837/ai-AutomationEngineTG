export interface Test {
  id: string;
  project_id: string;
  name: string;
  gherkin: string;
  created_at: string;
}

export interface CreateTestInput {
  projectId: string;
  name: string;
  gherkin: string;
}