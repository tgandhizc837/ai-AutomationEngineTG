import { openai } from "../config/openai.js";
import { query } from "../config/db.js";
import { ModelRouter } from "../orchestration/ModelRouter.js";
import { LlmUsageRepo } from "../repositories/LlmUsageRepo.js";

interface HealInput {
  workspaceId: string;
  projectId: string;
  executionStepId: string;
  failedSelector: string;
  elementLabel: string;
  domSnapshot: string;
  executionId: string;
}

interface HealResult {
  success: boolean;
  newSelector?: string;
  confidence: number;
}

export class HealingAgent {

  static async tryHeal(input: HealInput): Promise<HealResult> {

    // 1️⃣ Generate embedding
    const embedding = await this.generateEmbedding(input.elementLabel);

    // 2️⃣ Fetch similar selectors (PostgreSQL + pgvector)
    const candidates = await this.findSimilarSelectors(
      embedding,
      input.workspaceId,
      input.projectId
    );

    if (!candidates.length) {
      return { success: false, confidence: 0 };
    }

    // 3️⃣ LLM Selection
    const model = ModelRouter.route("healing");

    const prompt = `
You are an autonomous test healing agent.

Failed selector:
${input.failedSelector}

Element label:
${input.elementLabel}

DOM snapshot:
${input.domSnapshot}

Candidate selectors:
${candidates.map((c, i) => `${i + 1}. ${c.selector}`).join("\n")}

Return JSON:
{
  "selector": "...",
  "confidence": 0-1
}
`;

    const response = await openai.chat.completions.create({
      model,
      messages: [{ role: "user", content: prompt }],
      temperature: 0.2,
    });

    let parsed: any = {};

    try {
      parsed = JSON.parse(response.choices[0].message.content ?? "{}");
    } catch {
      return { success: false, confidence: 0 };
    }

    const confidence = parsed.confidence ?? 0;

    if (!parsed.selector || confidence < 0.6) {
      return { success: false, confidence };
    }

    // 4️⃣ Store healing event
    await this.saveHealingEvent(input, parsed.selector, confidence, candidates[0]);

    // 5️⃣ Log LLM usage
    await LlmUsageRepo.log({
      workspaceId: input.workspaceId,
      executionId: input.executionId,
      model,
      promptTokens: response.usage?.prompt_tokens ?? 0,
      completionTokens: response.usage?.completion_tokens ?? 0,
      cost: this.estimateCost(
        model,
        response.usage?.prompt_tokens ?? 0,
        response.usage?.completion_tokens ?? 0
      ),
    });

    return {
      success: true,
      newSelector: parsed.selector,
      confidence,
    };
  }

  // -------------------------
  // VECTOR SEARCH (pgvector)
  // -------------------------

  private static async findSimilarSelectors(
    embedding: number[],
    workspaceId: string,
    projectId: string
  ) {
    const rows = await query(
      `
      SELECT selector, 1 - (embedding <=> $1) AS similarity
      FROM locator_memory
      WHERE workspace_id = $2
        AND project_id = $3
      ORDER BY embedding <=> $1
      LIMIT 5
      `,
      [`[${embedding.join(",")}]`, workspaceId, projectId]
    );

    return rows;
  }

  // -------------------------
  // SAVE HEALING EVENT
  // -------------------------

  private static async saveHealingEvent(
    input: HealInput,
    newSelector: string,
    confidence: number,
    topCandidate: any
  ) {
    await query(
      `
      INSERT INTO healing_events(
        execution_step_id,
        old_selector,
        new_selector,
        similarity_score,
        confidence,
        success
      )
      VALUES($1, $2, $3, $4, $5, $6)
      `,
      [
        input.executionStepId,
        input.failedSelector,
        newSelector,
        topCandidate?.similarity ?? null,
        confidence,
        true
      ]
    );
  }

  // -------------------------
  // EMBEDDING
  // -------------------------

  private static async generateEmbedding(text: string): Promise<number[]> {
    const response = await openai.embeddings.create({
      model: "text-embedding-3-small",
      input: text,
    });

    return response.data[0].embedding;
  }

  // -------------------------
  // COST ESTIMATION
  // -------------------------

  private static estimateCost(
    model: string,
    promptTokens: number,
    completionTokens: number
  ): number {
    const pricePer1kPrompt = 0.00015;
    const pricePer1kCompletion = 0.0006;

    return (
      (promptTokens / 1000) * pricePer1kPrompt +
      (completionTokens / 1000) * pricePer1kCompletion
    );
  }
}