import { openai } from "../config/openai";
import { ModelRouter } from "../orchestration/ModelRouter";

const apiKey = process.env.OPENAI_API_KEY; // or the exact env name your app uses
if (!apiKey) throw new Error("Missing OPENAI_API_KEY");

// optional one-time debug (masked)
console.log("Using OpenAI key:", `${apiKey.slice(0, 7)}...${apiKey.slice(-4)}`);

export class PlanningAgent {
  static async plan(gherkin: string) {
    const model = process.env.PLANNING_MODEL || ModelRouter.route("planning");

    const response = await openai.chat.completions.create({
      model,
      messages: [
        {
          role: "system",
          content: `You are a test planning AI. Given a Gherkin scenario, return ONLY a JSON object with this shape:
{
  "steps": ["step description 1", "step description 2", ...]
}
No markdown, no explanation. JSON only.`,
        },
        { role: "user", content: gherkin },
      ],
      temperature: 0,
      response_format: { type: "json_object" },
    });

    return response.choices[0].message.content;
  }
}