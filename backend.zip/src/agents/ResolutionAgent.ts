import { openai } from "../config/openai.js";
import { query } from "../config/db.js";
import { ModelRouter } from "../orchestration/ModelRouter.js";
import { LlmUsageRepo } from "../repositories/LlmUsageRepo.js";
import { LlmCacheRepo } from "../repositories/LlmCacheRepo.js";

interface ResolutionInput {
  workspaceId: string;
  projectId: string;
  executionId: string;
  stepText: string;
  domSnapshot: string;
}

interface ResolutionResult {
  action: "click" | "type" | "assert";
  selector: string;
  value?: string;
  confidence: number;
}

export class ResolutionAgent {

  static async resolve(input: ResolutionInput): Promise<ResolutionResult> {

    // 1️⃣ Choose model
    const model = ModelRouter.route("resolution");

    // 2️⃣ Check LLM cache — same step in same project always targets same element
    const cacheKey = LlmCacheRepo.makeKey(input.projectId, input.stepText);
    const cached = await LlmCacheRepo.lookup(cacheKey);
    if (cached) {
      console.log(`⚡ [ResolutionAgent] Cache hit for "${input.stepText}"`);
      return cached as ResolutionResult;
    }

    // 3️⃣ Semantic memory lookup via pgvector
    //    "I click Login" finds "I click Sign in" because embeddings are close
    const embeddingRes = await openai.embeddings.create({
      model: "text-embedding-3-small",
      input: input.stepText.trim().toLowerCase(),
    });
    const stepEmbedding = embeddingRes.data[0].embedding;

    const similarMemory = await this.findSimilarMemory(
      input.workspaceId,
      input.projectId,
      stepEmbedding
    );

    // If a past selector is highly similar (≥0.92) reuse it without calling LLM
    if (similarMemory && similarMemory.similarity >= 0.92) {
      console.log(`🧠 [ResolutionAgent] Semantic memory hit (similarity=${similarMemory.similarity.toFixed(3)}) for "${input.stepText}" → selector "${similarMemory.selector}"`);
      const action = this.inferAction(input.stepText);
      return { action, selector: similarMemory.selector, confidence: similarMemory.similarity };
    }

    // 4️⃣ Fetch recent verified selectors as context for LLM
    const memories = await this.getLocatorMemory(
      input.workspaceId,
      input.projectId
    );

    // Include the best semantic match in context too (even if below threshold)
    const semanticHint = similarMemory
      ? `\nBest semantic match (similarity=${similarMemory.similarity.toFixed(2)}): "${similarMemory.label}" → ${similarMemory.selector}`
      : "";

    const memoryContext =
      memories.length > 0
        ? memories
            .map((m: any) => `Label: ${m.label} → Selector: ${m.selector}`)
            .join("\n") + semanticHint
        : semanticHint || "None";

    // 4️⃣ Prompt
    const prompt = `
You are an AI test resolution engine for Playwright browser automation.

Step text:
"${input.stepText}"

Available interactive elements (from live DOM):
${input.domSnapshot}

Known working selectors for this project:
${memoryContext}

Return JSON only (no markdown):
{
  "action": "click" | "type" | "assert",
  "selector": "<playwright selector>",
  "value": "<string, only if action is type>",
  "confidence": <0-1>
}

SELECTOR RULES:
- NEVER use CSS id selectors (#login, #btn) or class selectors (.btn-primary)
- NEVER use tag-specific has-text selectors like a:has-text() or button:has-text() — the element tag may change
- For action "assert": ALWAYS use plain text= selector: text=We couldn't find an account
  Never use div:has-text() for asserts — it matches hidden parent elements
- PREFER tag-agnostic selectors that survive DOM refactoring:
  text=Login
  [aria-label="Login"]
  input[placeholder*="Email" i]
  [role="button"]:has-text("Submit")
- ONLY use CSS attribute selectors if no text/role alternative exists
`;

    // 5️⃣ LLM Call
    const response = await openai.chat.completions.create({
      model,
      messages: [{ role: "user", content: prompt }],
      temperature: 0.1,
    });

    // replace the try/catch parse block with this:
    let parsed: ResolutionResult;
    try {
      const raw = response.choices[0].message.content ?? "{}";
      const clean = raw.replace(/```json\n?|```/g, "").trim();
      parsed = JSON.parse(clean);
    } catch {
      throw new Error("ResolutionAgent returned invalid JSON");
    }
    // 5️⃣ Validation
    if (!parsed.selector || !parsed.action) {
      throw new Error("ResolutionAgent returned incomplete result");
    }

    // NOTE: We intentionally do NOT cache here.
    // The result is stored in LlmCacheRepo only AFTER StepRunner verifies
    // the selector actually works. Caching unverified selectors causes
    // bad entries to be reused on every subsequent run.

    // 6️⃣ Log usage
    await LlmUsageRepo.log({
      workspaceId: input.workspaceId,
      executionId: input.executionId,
      model,
      promptTokens: response.usage?.prompt_tokens ?? 0,
      completionTokens: response.usage?.completion_tokens ?? 0,
      cost: this.estimateCost(
        model,
        response.usage?.prompt_tokens ?? 0,
        response.usage?.completion_tokens ?? 0
      ),
    });

    return parsed;
  }

  // -------------------------
  // pgvector: Semantic Memory Lookup
  // -------------------------

  private static async findSimilarMemory(
    workspaceId: string,
    projectId: string,
    embedding: number[]
  ): Promise<{ selector: string; label: string; similarity: number } | null> {
    try {
      const rows = await query(
        `
        SELECT selector, label, 1 - (embedding <=> $3) AS similarity
        FROM locator_memory
        WHERE workspace_id = $1
          AND project_id = $2
        ORDER BY embedding <=> $3
        LIMIT 1
        `,
        [workspaceId, projectId, `[${embedding.join(",")}]`]
      );
      if (!rows.length) return null;
      return rows[0] as { selector: string; label: string; similarity: number };
    } catch {
      return null;
    }
  }

  // -------------------------
  // Infer action from step text (used when skipping LLM via semantic memory)
  // -------------------------

  private static inferAction(stepText: string): "click" | "type" | "assert" {
    const lower = stepText.toLowerCase();
    if (lower.includes("click") || lower.includes("press") || lower.includes("tap")) return "click";
    if (lower.includes("enter") || lower.includes("type") || lower.includes("fill") || lower.includes("input")) return "type";
    return "assert";
  }

  // -------------------------
  // DB: Fetch recent verified selectors as LLM context
  // -------------------------

  private static async getLocatorMemory(
    workspaceId: string,
    projectId: string
  ) {
    const rows = await query(
      `
      SELECT label, selector
      FROM locator_memory
      WHERE workspace_id = $1
        AND project_id = $2
      ORDER BY created_at DESC
      LIMIT 10
      `,
      [workspaceId, projectId]
    );

    return rows;
  }

  // -------------------------
  // Cost Estimation
  // -------------------------

  private static estimateCost(
    model: string,
    promptTokens: number,
    completionTokens: number
  ): number {
    const pricePer1kPrompt = 0.00015;
    const pricePer1kCompletion = 0.0006;

    return (
      (promptTokens / 1000) * pricePer1kPrompt +
      (completionTokens / 1000) * pricePer1kCompletion
    );
  }
}