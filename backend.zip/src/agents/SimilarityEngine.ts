import { openai } from "../config/openai.js";
import { supabase } from "../config/supabase.js";

interface SimilarityInput {
  workspaceId: string;
  projectId: string;
  text: string; // label or semantic intent
  topK?: number;
  minSimilarity?: number;
}

export interface SimilarityResult {
  id: string;
  selector: string;
  elementLabel: string;
  similarity: number;
}

export class SimilarityEngine {
  // ----------------------------------------
  // Public API
  // ----------------------------------------

  static async search(input: SimilarityInput): Promise<SimilarityResult[]> {
    const topK = input.topK ?? 5;
    const minSimilarity = input.minSimilarity ?? 0.6;

    // 1️⃣ Generate embedding
    const embedding = await this.generateEmbedding(input.text);

    // 2️⃣ Call Supabase RPC
    const { data, error } = await supabase.rpc(
      "match_locator_memory",
      {
        query_embedding: embedding,
        match_workspace_id: input.workspaceId,
        match_project_id: input.projectId,
        match_count: topK,
      }
    );

    if (error) throw error;

    if (!data) return [];

    // 3️⃣ Filter by similarity threshold
    return data
      .filter((row: any) => row.similarity >= minSimilarity)
      .map((row: any) => ({
        id: row.id,
        selector: row.selector,
        elementLabel: row.label,
        similarity: row.similarity,
      }));
  }

  // ----------------------------------------
  // Embedding Generator
  // ----------------------------------------

  private static async generateEmbedding(text: string): Promise<number[]> {
    const response = await openai.embeddings.create({
      model: "text-embedding-3-small",
      input: text,
    });

    return response.data[0].embedding;
  }
}