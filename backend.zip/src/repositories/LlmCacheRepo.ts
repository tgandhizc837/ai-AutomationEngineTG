import { createHash } from "crypto";
import { query } from "../config/db.js";

// One-time CREATE TABLE guard (avoids repeated DDL on every call)
let tableReady = false;

const MAX_FAILURES = 1; // re-call LLM after first consecutive execution failure

async function ensureTable(): Promise<void> {
  if (tableReady) return;
  await query(`
    CREATE TABLE IF NOT EXISTS llm_cache (
      cache_key  TEXT        PRIMARY KEY,
      result     JSONB       NOT NULL,
      hit_count  INTEGER     DEFAULT 0,
      fail_count INTEGER     DEFAULT 0,
      last_hit   TIMESTAMPTZ,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
  // Add fail_count if table pre-existed without it
  await query(`
    ALTER TABLE llm_cache ADD COLUMN IF NOT EXISTS fail_count INTEGER DEFAULT 0
  `).catch(() => {});
  tableReady = true;
}

export class LlmCacheRepo {
  static makeKey(projectId: string, stepText: string): string {
    return createHash("sha256")
      .update(`${projectId}:${stepText.trim().toLowerCase()}`)
      .digest("hex");
  }

  /**
   * Look up a cached resolution result.
   * Returns null on miss, expired (fail_count >= MAX), or DB error.
   */
  static async lookup(key: string): Promise<any | null> {
    try {
      await ensureTable();
      const rows = await query(
        `SELECT result, fail_count FROM llm_cache WHERE cache_key = $1`,
        [key]
      );
      if (!rows.length) return null;

      const row = rows[0];
      if (row.fail_count >= MAX_FAILURES) {
        // Auto-expired — delete and force re-resolve via LLM
        await query(`DELETE FROM llm_cache WHERE cache_key = $1`, [key]);
        return null;
      }

      // Increment hit_count (non-critical, fire-and-forget)
      query(
        `UPDATE llm_cache SET hit_count = hit_count + 1, last_hit = NOW() WHERE cache_key = $1`,
        [key]
      ).catch(() => {});

      return row.result;
    } catch {
      return null;
    }
  }

  /**
   * Store a resolution result immediately (before execute()).
   * Called right after LLM responds so repeat runs skip the LLM entirely.
   * fail_count is reset to 0 when a selector is confirmed working (via storeVerified).
   */
  static async store(key: string, result: any): Promise<void> {
    try {
      await ensureTable();
      await query(
        `INSERT INTO llm_cache (cache_key, result, fail_count)
         VALUES ($1, $2::jsonb, 0)
         ON CONFLICT (cache_key) DO UPDATE
           SET result     = EXCLUDED.result,
               hit_count  = 0,
               last_hit   = NULL,
               created_at = NOW()
               -- do NOT reset fail_count here; storeVerified does that`,
        [key, JSON.stringify(result)]
      );
    } catch {
      // Non-fatal
    }
  }

  /**
   * Mark a cached entry as verified-working (selector executed successfully).
   * Resets fail_count to 0 so it is never auto-expired.
   */
  static async storeVerified(key: string, result: any): Promise<void> {
    try {
      await ensureTable();
      await query(
        `INSERT INTO llm_cache (cache_key, result, fail_count)
         VALUES ($1, $2::jsonb, 0)
         ON CONFLICT (cache_key) DO UPDATE
           SET result     = EXCLUDED.result,
               fail_count = 0,
               hit_count  = 0,
               last_hit   = NULL,
               created_at = NOW()`,
        [key, JSON.stringify(result)]
      );
    } catch {
      // Non-fatal
    }
  }

  /**
   * Record a selector execution failure.
   * After MAX_FAILURES the entry is deleted so the next run re-calls LLM.
   */
  static async recordFailure(key: string): Promise<void> {
    try {
      await ensureTable();
      await query(
        `UPDATE llm_cache
         SET fail_count = fail_count + 1
         WHERE cache_key = $1`,
        [key]
      );
      // Prune if expired
      await query(
        `DELETE FROM llm_cache WHERE cache_key = $1 AND fail_count >= $2`,
        [key, MAX_FAILURES]
      );
    } catch {
      // Non-fatal
    }
  }

  /**
   * Hard-delete a cache entry (used when healing finds a better selector).
   */
  static async invalidate(key: string): Promise<void> {
    try {
      await ensureTable();
      await query(`DELETE FROM llm_cache WHERE cache_key = $1`, [key]);
    } catch {
      // Non-fatal
    }
  }
}

