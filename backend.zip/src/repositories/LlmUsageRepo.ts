import { query } from "../config/db.js";

export class LlmUsageRepo {

  static async log(data: {
    workspaceId: string
    executionId: string
    model: string
    promptTokens: number
    completionTokens: number
    cost: number
  }) {

    await query(
      `
      INSERT INTO llm_usage
      (
        workspace_id,
        execution_id,
        model,
        prompt_tokens,
        completion_tokens,
        cost
      )
      VALUES($1,$2,$3,$4,$5,$6)
      `,
      [
        data.workspaceId,
        data.executionId,
        data.model,
        data.promptTokens,
        data.completionTokens,
        data.cost
      ]
    );

  }

}