import { query } from "../config/db.js";
import { openai } from "../config/openai.js";

export class LocatorMemoryRepo {

  static async store(
    workspaceId: string,
    projectId: string,
    selector: string,
    label: string,
    embedding: number[]
  ) {

    await query(
      `
      INSERT INTO locator_memory
      (workspace_id,project_id,selector,label,embedding)
      VALUES($1,$2,$3,$4,$5)
      `,
      [workspaceId, projectId, selector, label, `[${embedding.join(",")}]`]
    );

  }

  /**
   * remember — called after a step PASSES.
   * Generates the embedding internally and upserts (delete+insert)
   * so the latest verified-good selector is always stored.
   * Non-fatal: any DB or OpenAI error is swallowed.
   */
  static async remember(
    workspaceId: string,
    projectId: string,
    label: string,
    selector: string
  ): Promise<void> {
    try {
      const res = await openai.embeddings.create({
        model: "text-embedding-3-small",
        input: label.trim().toLowerCase(),
      });
      const embedding = res.data[0].embedding;
      const vec = `[${embedding.join(",")}]`;

      // Delete-then-insert acts as upsert without needing a UNIQUE constraint
      await query(
        `DELETE FROM locator_memory
         WHERE workspace_id=$1 AND project_id=$2 AND label=$3`,
        [workspaceId, projectId, label]
      );
      await query(
        `INSERT INTO locator_memory
           (workspace_id, project_id, label, selector, embedding)
         VALUES ($1, $2, $3, $4, $5)`,
        [workspaceId, projectId, label, selector, vec]
      );
    } catch {
      // Non-fatal — best-effort
    }
  }

  static async findSimilar(
    workspaceId: string,
    projectId: string,
    embedding: number[]
  ) {

    return query(
      `
      SELECT selector,
             1 - (embedding <=> $3) AS similarity
      FROM locator_memory
      WHERE workspace_id=$1
      AND project_id=$2
      ORDER BY embedding <=> $3
      LIMIT 5
      `,
      [workspaceId, projectId, `[${embedding.join(",")}]`]
    );

  }

}