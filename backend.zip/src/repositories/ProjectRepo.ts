import { query } from "../config/db.js";

export class ProjectRepo {

  static async create(workspaceId: string, name: string) {

    const rows = await query(
      `INSERT INTO projects(workspace_id, name)
       VALUES($1,$2)
       RETURNING *`,
      [workspaceId, name]
    );

    return rows[0];
  }

  static async findByWorkspace(workspaceId: string) {

    return query(
      `SELECT * FROM projects
       WHERE workspace_id=$1
       ORDER BY created_at DESC`,
      [workspaceId]
    );

  }

  static async findById(id: string) {

    const rows = await query(
      `SELECT * FROM projects WHERE id=$1`,
      [id]
    );

    return rows[0];
  }

  static async delete(id: string) {

    await query(
      `DELETE FROM projects WHERE id=$1`,
      [id]
    );

  }

}