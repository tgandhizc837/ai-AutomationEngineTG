import { query } from "../config/db.js";

export class HealingEventRepo {

  static async create(data: {
    executionStepId: string
    oldSelector: string
    newSelector: string
    similarityScore: number | null
    confidence: number
    success: boolean
  }) {

    await query(
      `
      INSERT INTO healing_events
      (
        execution_step_id,
        old_selector,
        new_selector,
        similarity_score,
        confidence,
        success
      )
      VALUES($1,$2,$3,$4,$5,$6)
      `,
      [
        data.executionStepId,
        data.oldSelector,
        data.newSelector,
        data.similarityScore,
        data.confidence,
        data.success
      ]
    );

  }

}