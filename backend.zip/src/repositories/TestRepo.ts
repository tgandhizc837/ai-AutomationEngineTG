import { query } from "../config/db.js";

export class TestRepo {

  static async create(projectId: string, name: string, gherkin: string) {
    const rows = await query(
      `INSERT INTO tests(project_id, name, gherkin)
       VALUES($1, $2, $3)
       RETURNING *`,
      [projectId, name, gherkin]
    );
    return rows[0];
  }

  static async findByProject(projectId: string) {
    return query(
      `SELECT * FROM tests WHERE project_id = $1`,
      [projectId]
    );
  }

  // ✅ ADDED — required by ExecutionOrchestrator
  static async findById(id: string) {
    const rows = await query(
      `SELECT * FROM tests WHERE id = $1`,
      [id]
    );
    return rows[0] ?? null;
  }

}