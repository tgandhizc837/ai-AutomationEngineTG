import { query } from "../config/db.js";

export class ExecutionStepRepo {

  static async create(data: {
    executionId: string;
    testId: string;
    stepIndex: number;
    action: string;
    selector: string;
  }) {
    const rows = await query(
      `
      INSERT INTO execution_steps
      (execution_id, test_id, step_index, action, selector, status, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, 'pending', now(), now())
      RETURNING *
      `,
      [
        data.executionId,
        data.testId,
        data.stepIndex,
        data.action,
        data.selector
      ]
    );

    return rows[0];
  }

  static async markPassed(id: string, duration?: number) {
    await query(
      `
      UPDATE execution_steps
      SET status = 'passed',
          updated_at = now()
          ${duration !== undefined ? ", duration_ms = $2" : ""}
      WHERE id = $1
      `,
      duration !== undefined ? [id, duration] : [id]
    );
  }

  static async markFailed(id: string, error: string) {
    await query(
      `
      UPDATE execution_steps
      SET status = 'failed',
          error = $2,
          updated_at = now()
      WHERE id = $1
      `,
      [id, error]
    );
  }

  // 🔥 Alias to fix your runtime error
  static async markFailure(id: string, error: string) {
    return this.markFailed(id, error);
  }

  static async markSuccess(id: string) {
    await query(
      `
      UPDATE execution_steps
      SET status = 'passed',
          updated_at = now()
      WHERE id = $1
      `,
      [id]
    );
  }

  static async markHealed(id: string, newSelector: string) {
    await query(
      `
      UPDATE execution_steps
      SET status = 'healed',
          selector = $2,
          updated_at = now()
      WHERE id = $1
      `,
      [id, newSelector]
    );
  }

}