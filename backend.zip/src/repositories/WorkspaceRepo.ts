import { query } from "../config/db.js";

export class WorkspaceRepo {

  static async create(name: string, plan: string) {
    const rows = await query(
      `INSERT INTO workspaces(name, plan)
       VALUES($1,$2)
       RETURNING *`,
      [name, plan]
    );

    return rows[0];
  }

  static async findAll() {
    return query(`SELECT * FROM workspaces ORDER BY created_at DESC`);
  }

  static async findById(id: string) {
    const rows = await query(
      `SELECT * FROM workspaces WHERE id=$1`,
      [id]
    );

    return rows[0];
  }

  static async delete(id: string) {
    await query(
      `DELETE FROM workspaces WHERE id=$1`,
      [id]
    );
  }

}