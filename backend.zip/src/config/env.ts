import dotenv from "dotenv"

dotenv.config()

export const env = {
  PORT: Number(process.env.PORT) || 4000,

  // frontend domain for CORS
  FRONTEND_URL: process.env.FRONTEND_URL || "http://localhost:3000",

  // PostgreSQL
  DATABASE_URL: process.env.DATABASE_URL!,

  // Redis
  REDIS_URL: process.env.REDIS_URL || "redis://localhost:6379",

  // OpenAI
  OPENAI_API_KEY: process.env.OPENAI_API_KEY!,

  // JWT (for auth tokens later)
  JWT_SECRET: process.env.JWT_SECRET || "super-secret-key"
}