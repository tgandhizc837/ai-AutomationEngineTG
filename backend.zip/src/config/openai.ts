import OpenAI from "openai";

type LlmProvider = "openai" | "github";

const forcedProvider = (process.env.LLM_PROVIDER || "").trim().toLowerCase();
const openaiKey = (process.env.OPENAI_API_KEY || "").trim();
const githubKey = ((process.env.GITHUB_MODELS_TOKEN || process.env.GITHUB_TOKEN) || "").trim();

if (forcedProvider && forcedProvider !== "openai" && forcedProvider !== "github") {
  throw new Error(`Invalid LLM_PROVIDER='${forcedProvider}'. Use 'openai' or 'github'.`);
}
if (githubKey === "your_github_models_token_here") {
  throw new Error("GITHUB_MODELS_TOKEN is a placeholder. Set a real token.");
}

function resolveProvider(): { provider: LlmProvider; apiKey: string; baseURL?: string } {
  if (forcedProvider === "openai") {
    if (!openaiKey) throw new Error("LLM_PROVIDER=openai but OPENAI_API_KEY is missing");
    return { provider: "openai", apiKey: openaiKey, baseURL: process.env.OPENAI_BASE_URL };
  }

  if (forcedProvider === "github") {
    if (!githubKey) throw new Error("LLM_PROVIDER=github but GITHUB_MODELS_TOKEN/GITHUB_TOKEN is missing");
    return {
      provider: "github",
      apiKey: githubKey,
      baseURL: process.env.GITHUB_MODELS_BASE_URL || "https://models.inference.ai.azure.com",
    };
  }

  if (openaiKey) return { provider: "openai", apiKey: openaiKey, baseURL: process.env.OPENAI_BASE_URL };
  if (githubKey) {
    return {
      provider: "github",
      apiKey: githubKey,
      baseURL: process.env.GITHUB_MODELS_BASE_URL || "https://models.inference.ai.azure.com",
    };
  }

  throw new Error("No LLM key found. Set OPENAI_API_KEY or GITHUB_MODELS_TOKEN/GITHUB_TOKEN.");
}

const cfg = resolveProvider();

export const llmProvider = cfg.provider;
export const openai = new OpenAI({
  apiKey: cfg.apiKey,
  ...(cfg.baseURL ? { baseURL: cfg.baseURL } : {}),
});

console.log(`🤖 Using LLM provider: ${llmProvider}, model: ${process.env.PLANNING_MODEL || "from router"}`);