export const bullmqConnection = {
  host: "127.0.0.1",
  port: 6379,
};