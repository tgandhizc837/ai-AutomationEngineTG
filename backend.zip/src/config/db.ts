import { Pool } from "pg"

export const db = new Pool({
  connectionString: process.env.DATABASE_URL
})
console.log("DB URL:", process.env.DATABASE_URL)

db.on("connect", () => {
  console.log("PostgreSQL connected")
})

db.on("error", (err) => {
  console.error("PostgreSQL error:", err)
})

export async function query(text: string, params?: any[]) {
  const result = await db.query(text, params)
  return result.rows
}