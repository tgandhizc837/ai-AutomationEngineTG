import Fastify from "fastify";
import workspaceModule from "./modules/workspace/index.js";
import projectModule from "./modules/project/index.js";
import environmentModule from "./modules/environment/index.js";
import testModule from "./modules/test/index.js";
import executionModule from "./modules/execution/index.js";
import healingModule from "./modules/healing/index.js";
import llmModule from "./modules/llm/index.js";
import billingModule from "./modules/billing/index.js";


export const app = Fastify({ logger: true });

app.register(workspaceModule);
app.register(projectModule);
app.register(environmentModule);
app.register(testModule);
app.register(executionModule);
app.register(healingModule);
app.register(llmModule);
app.register(billingModule);