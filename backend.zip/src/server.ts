import "dotenv/config";
import path from "path";
import fs from "fs";
import Fastify from "fastify";
import cors from "@fastify/cors";
import fastifyCookie from "@fastify/cookie";
import rateLimit from "@fastify/rate-limit";
import fastifyStatic from "@fastify/static";
import multipart from "@fastify/multipart";

// Routes
import authRoutes from "./modules/auth/auth.routes";
import workspaceRoutes from "./modules/workspace/workspace.routes";
import projectRoutes from "./modules/project/project.routes";
import testRoutes from "./modules/test/test.routes";
import excelImportRoutes from "./modules/test/excel-import.routes";
import executionRoutes from "./modules/execution/execution.routes";
import healingRoutes from "./modules/healing/healing.routes";

// Auth middleware + DB (for inline stats route)
import { authMiddleware } from "./modules/auth/auth.middleware";
import { query } from "./config/db";

// Queue
import { startWorker, executionQueue } from "./queue/executionQueue";

const app = Fastify({
  logger: {
    level: "info",
  },
});

async function start() {
  try {
    // =========================
    // 🔹 Plugins
    // =========================
    await app.register(cors, {
      origin: [
        "http://localhost:3000",
        "http://localhost:5173",
      ],
      credentials: true,
    });

    await app.register(fastifyCookie, {
      secret: process.env.COOKIE_SECRET || "supersecret",
    });

    await app.register(rateLimit, {
      max: 100,
      timeWindow: "1 minute",
    });

    await app.register(multipart, {
      limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB max
    });

    // =========================
    // 🎥 Static: Recordings
    // =========================
    const recordingsDir = path.resolve(process.cwd(), "recordings");
    if (!fs.existsSync(recordingsDir)) fs.mkdirSync(recordingsDir, { recursive: true });

    await app.register(fastifyStatic, {
      root: recordingsDir,
      prefix: "/recordings/",
      decorateReply: false,
    });

    // =========================
    // 🔹 Routes
    // =========================
    await app.register(authRoutes,      { prefix: "/auth" });
    await app.register(workspaceRoutes, { prefix: "/workspaces" });
    await app.register(projectRoutes,   { prefix: "/projects" });
    await app.register(testRoutes,      { prefix: "/tests" });
    await app.register(excelImportRoutes, { prefix: "/tests" });

    // =========================
    // � GET /executions/all  (must be registered before the :id plugin)
    // =========================
    app.get(
      "/executions/all",
      { preHandler: authMiddleware as any },
      async (req: any, res: any) => {
        try {
          const userId = req.user.id;

          const rows = await query(
            `SELECT
               e.id,
               e.status,
               e.created_at,
               e.started_at,
               e.completed_at,
               t.id   AS test_id,
               t.name AS test_name,
               p.id   AS project_id,
               p.name AS project_name
             FROM executions e
             JOIN tests    t ON t.id = e.test_id
             JOIN projects p ON p.id = t.project_id
             WHERE e.user_id = $1
             ORDER BY e.created_at DESC
             LIMIT 200`,
            [userId]
          );

          return res.send(rows);
        } catch (err: any) {
          return res.status(500).send({ error: err.message });
        }
      }
    );

    // =========================
    // �📊 GET /executions/stats  (must be registered before the :id plugin)
    // =========================
    app.get(
      "/executions/stats",
      { preHandler: authMiddleware as any },
      async (req: any, res: any) => {
        try {
          const userId = req.user.id;

          const execRows = await query(
            `SELECT
               COUNT(*)                                          AS total,
               COUNT(*) FILTER (WHERE status = 'completed')     AS succeeded,
               COUNT(*) FILTER (WHERE status = 'failed')        AS failed,
               AVG(
                 EXTRACT(EPOCH FROM (completed_at - started_at)) * 1000
               ) FILTER (WHERE completed_at IS NOT NULL
                           AND started_at  IS NOT NULL)         AS avg_duration_ms
             FROM executions
             WHERE user_id = $1`,
            [userId]
          );

          const usageRows = await query(
            `SELECT
               COALESCE(SUM(prompt_tokens + completion_tokens), 0) AS total_tokens,
               COALESCE(SUM(cost), 0)                             AS total_cost
             FROM llm_usage
             WHERE workspace_id IN (
               SELECT workspace_id FROM executions WHERE user_id = $1 LIMIT 1
             )`,
            [userId]
          );

          const e = execRows[0];
          const u = usageRows[0];

          const total     = parseInt(e.total)     || 0;
          const succeeded = parseInt(e.succeeded) || 0;

          return res.send({
            total_executions: total,
            success_rate:     total > 0 ? Math.round((succeeded / total) * 100) : 0,
            avg_duration_ms:  e.avg_duration_ms ? Math.round(parseFloat(e.avg_duration_ms)) : null,
            total_tokens:     parseInt(u.total_tokens) || 0,
            total_cost_usd:   parseFloat(u.total_cost)  || 0,
          });
        } catch (err: any) {
          return res.status(500).send({ error: err.message });
        }
      }
    );

    await app.register(executionRoutes, { prefix: "/executions" });
    await app.register(healingRoutes,   { prefix: "/healing" });

    // =========================
    // 🔹 Health Check
    // =========================
    app.get("/", async () => ({
      status: "OK",
      service: "AI Test Automation Backend",
    }));

    // =========================
    // 🔹 Global Error Handler
    // =========================
    app.setErrorHandler((error: any, _request, reply) => {
      app.log.error(error);
      reply.status(error?.statusCode || 500).send({
        success: false,
        message: error?.message || "Internal Server Error",
      });
    });

    // =========================
    // 🔹 Start Server
    // =========================
    const PORT = Number(process.env.PORT) || 4000;

    await app.listen({ port: PORT, host: "0.0.0.0" });

    app.log.info(`🚀 Server running on http://localhost:${PORT}`);

    // =========================
    // 🔥 Start BullMQ Worker
    // =========================
    const worker = startWorker();

    worker.on("ready", () => {
      app.log.info("🧠 Worker ready and connected to Redis");
    });

    worker.on("error", (err) => {
      app.log.error({ msg: "❌ Worker error:", error: err instanceof Error ? err.message : String(err) });
    });

    worker.on("completed", (job) => {
      app.log.info(`✅ Job ${job.id} completed`);
    });

    worker.on("failed", (job, err) => {
      app.log.error(`❌ Job ${job?.id} failed: ${err.message}`);
    });

    app.log.info("✅ BullMQ worker started");

    // =========================
    // 🔹 Graceful Shutdown
    // =========================
    const shutdown = async (signal: string) => {
      app.log.info(`${signal} received — shutting down`);

      await worker.close();
      await app.close();

      process.exit(0);
    };

    process.once("SIGINT", () => shutdown("SIGINT"));
    process.once("SIGTERM", () => shutdown("SIGTERM"));

  } catch (err) {
    app.log.error(err);
    process.exit(1);
  }
}

start();