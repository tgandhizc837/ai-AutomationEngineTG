import { FastifyInstance } from "fastify";
import workspaceRoutes from "../modules/workspace/workspace.routes.js";

export async function registerRoutes(app: FastifyInstance) {

  app.register(workspaceRoutes);

}