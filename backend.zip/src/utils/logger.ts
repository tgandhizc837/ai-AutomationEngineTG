type LogLevel = "debug" | "info" | "warn" | "error";

const isProd = process.env.NODE_ENV === "production";

interface LogContext {
  [key: string]: unknown;
}

function formatLog(
  level: LogLevel,
  message: string,
  context?: LogContext
) {
  const base = {
    level,
    message,
    timestamp: new Date().toISOString(),
    ...context,
  };

  if (isProd) {
    return JSON.stringify(base);
  }

  // Dev-friendly format
  return `[${base.timestamp}] ${level.toUpperCase()} — ${message} ${
    context ? JSON.stringify(context, null, 2) : ""
  }`;
}

function log(
  level: LogLevel,
  message: string,
  context?: LogContext
) {
  const formatted = formatLog(level, message, context);

  switch (level) {
    case "debug":
      console.debug(formatted);
      break;
    case "info":
      console.info(formatted);
      break;
    case "warn":
      console.warn(formatted);
      break;
    case "error":
      console.error(formatted);
      break;
  }
}

export const logger = {
  debug: (message: string, context?: LogContext) =>
    log("debug", message, context),

  info: (message: string, context?: LogContext) =>
    log("info", message, context),

  warn: (message: string, context?: LogContext) =>
    log("warn", message, context),

  error: (
    message: string,
    error?: unknown,
    context?: LogContext
  ) => {
    log("error", message, {
      ...context,
      error:
        error instanceof Error
          ? {
              name: error.name,
              message: error.message,
              stack: error.stack,
            }
          : error,
    });
  },
};