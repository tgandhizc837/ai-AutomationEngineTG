type MetricValue = number;

interface Counter {
  name: string;
  value: MetricValue;
}

interface Timer {
  name: string;
  start: number;
}

const counters = new Map<string, Counter>();

export const metrics = {
  /**
   * Increment counter
   */
  increment(name: string, value = 1) {
    const existing = counters.get(name);

    if (existing) {
      existing.value += value;
    } else {
      counters.set(name, { name, value });
    }
  },

  /**
   * Get counter value
   */
  get(name: string): number {
    return counters.get(name)?.value ?? 0;
  },

  /**
   * Start timer
   */
  startTimer(name: string): Timer {
    return {
      name,
      start: performance.now(),
    };
  },

  /**
   * End timer and return duration in ms
   */
  endTimer(timer: Timer): number {
    const duration = performance.now() - timer.start;

    this.increment(`${timer.name}_count`);
    this.increment(`${timer.name}_total_ms`, duration);

    return duration;
  },

  /**
   * Get all metrics snapshot
   */
  snapshot() {
    const result: Record<string, number> = {};

    for (const [key, counter] of counters.entries()) {
      result[key] = counter.value;
    }

    return result;
  },

  /**
   * Reset metrics (useful in tests)
   */
  reset() {
    counters.clear();
  },
};