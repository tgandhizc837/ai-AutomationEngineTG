import crypto from "crypto";

/**
 * Generate SHA256 hash of a string
 */
export function sha256(input: string): string {
  return crypto
    .createHash("sha256")
    .update(input)
    .digest("hex");
}

/**
 * Generate SHA1 hash (useful for short deterministic keys)
 */
export function sha1(input: string): string {
  return crypto
    .createHash("sha1")
    .update(input)
    .digest("hex");
}

/**
 * Generate HMAC SHA256 (for signed tokens)
 */
export function hmacSHA256(
  input: string,
  secret: string
): string {
  return crypto
    .createHmac("sha256", secret)
    .update(input)
    .digest("hex");
}

/**
 * Generate secure random token
 */
export function randomToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString("hex");
}

/**
 * Generate deterministic short ID
 */
export function shortHash(input: string): string {
  return sha1(input).substring(0, 12);
}