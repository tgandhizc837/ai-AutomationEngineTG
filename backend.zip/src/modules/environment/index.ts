import { FastifyInstance } from "fastify";
import { supabase } from "../../config/supabase.js";

export default async function environmentModule(app: FastifyInstance) {

  app.post("/environments", async (req) => {
    const { workspaceId, projectId, name, baseUrl } = req.body as any;

    const { data, error } = await supabase
      .from("environments")
      .insert({
        workspace_id: workspaceId,
        project_id: projectId,
        name,
        base_url: baseUrl
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  });
}