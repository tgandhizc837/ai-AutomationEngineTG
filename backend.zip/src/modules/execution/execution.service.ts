import { ExecutionRepository } from "./execution.repository"
import { executionQueue } from "../../queue/executionQueue"
import { query } from "../../config/db"

export class ExecutionService {
  private executionRepo: ExecutionRepository

  constructor() {
    this.executionRepo = new ExecutionRepository()
  }

  // =========================
  // 🚀 CREATE EXECUTION
  // =========================
  async createExecution(
    testId: string,
    projectId: string,
    userId: string,
    browser: string = "chromium",
    headless: boolean = true
  ) {
    console.log("🔥 Service called:", { testId, projectId, userId })

    // ✅ Guards
    if (!testId)    throw new Error("testId is required")
    if (!projectId) throw new Error("projectId is required")
    if (!userId)    throw new Error("userId is required")

    // 🔐 STEP 1: Fetch project + workspace_id
    const projectRows = await query(
      `SELECT p.id, p.workspace_id
       FROM projects p
       WHERE p.id = $1`,
      [projectId]
    )

    if (!projectRows.length) {
      throw new Error("Project not found")
    }

    const workspaceId: string = projectRows[0].workspace_id

    if (!workspaceId) {
      throw new Error("Project has no workspace assigned")
    }

    console.log("✅ Project found, workspace_id:", workspaceId)

    // ✅ STEP 2: Create execution with correct workspace_id
    const execution = await this.executionRepo.create(
      testId,
      projectId,
      workspaceId,
      userId,
      browser
    )

    console.log("✅ Execution created:", execution)

    // 🚀 STEP 3: Push to queue
    await executionQueue.add("run-test", {
      executionId: execution.id,
      testId,
      projectId,
      browser,
      headless,
    })

    return execution
  }

  // =========================
  // 🔍 GET EXECUTION
  // =========================
  async getExecutionById(id: string) {
    if (!id) throw new Error("execution id is required")
    return this.executionRepo.findById(id)
  }

  // =========================
  // 🔄 UPDATE STATUS
  // =========================
  async updateExecutionStatus(
    id: string,
    status: string,
    result?: any
  ) {
    if (!id || !status) {
      throw new Error("id and status are required")
    }
    await this.executionRepo.updateStatus(id, status, result)
  }

  // =========================
  // 🚀 MARK RUNNING
  // =========================
  async markRunning(id: string) {
    if (!id) throw new Error("execution id is required")
    await this.executionRepo.markRunning(id)
  }

  // =========================
  // ✅ MARK COMPLETED
  // =========================
  async markCompleted(id: string) {
    if (!id) throw new Error("execution id is required")
    await this.executionRepo.markCompleted(id)
  }

  // =========================
  // ❌ MARK FAILED
  // =========================
  async markFailed(id: string, error?: string) {
    if (!id) throw new Error("execution id is required")
    await this.executionRepo.markFailed(id, error)
  }
}