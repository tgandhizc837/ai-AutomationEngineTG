import { authMiddleware } from "../auth/auth.middleware"
import { ExecutionService } from "./execution.service"
import { query } from "../../config/db"

export default async function executionRoutes(app: any) {

  const executionService = new ExecutionService()

  // =========================
  // POST /executions
  // Trigger a new test run
  // =========================
  app.post(
    "/",
    { preHandler: authMiddleware },
    async (req: any, res: any) => {
      try {
        const { test_id, project_id, browser = "chromium", headless = true } = req.body

        console.log(`🌐 [POST /executions] browser="${browser}" headless=${headless} test_id=${test_id}`)

        if (!test_id)    return res.status(400).send({ error: "test_id is required" })
        if (!project_id) return res.status(400).send({ error: "project_id is required" })

        const VALID_BROWSERS = ["chromium", "firefox", "webkit", "chrome", "msedge"]
        if (!VALID_BROWSERS.includes(browser)) {
          return res.status(400).send({ error: `Invalid browser. Must be one of: ${VALID_BROWSERS.join(", ")}` })
        }

        const execution = await executionService.createExecution(
          test_id,
          project_id,
          req.user.id,
          browser,
          !!headless
        )

        return res.status(201).send(execution)
      } catch (err: any) {
        console.error(err)
        return res.status(500).send({ error: err.message })
      }
    }
  )

  // =========================
  // GET /executions?test_id=X
  // Execution history for a test
  // =========================
  app.get(
    "/",
    { preHandler: authMiddleware },
    async (req: any, res: any) => {
      try {
        const { test_id } = req.query

        if (!test_id) {
          return res.status(400).send({ error: "test_id is required" })
        }

        const rows = await query(
          `SELECT * FROM executions
           WHERE test_id = $1
           ORDER BY created_at DESC`,
          [test_id]
        )

        return res.send(rows)
      } catch (err: any) {
        return res.status(500).send({ error: err.message })
      }
    }
  )

  // =========================
  // GET /executions/:id
  // Poll a single execution status
  // =========================
  app.get(
    "/:id",
    { preHandler: authMiddleware },
    async (req: any, res: any) => {
      try {
        const { id } = req.params

        const execution = await executionService.getExecutionById(id)

        if (!execution) {
          return res.status(404).send({ error: "Execution not found" })
        }

        return res.send(execution)
      } catch (err: any) {
        return res.status(500).send({ error: err.message })
      }
    }
  )

  // =========================
  // GET /executions/:id/steps
  // Step-by-step results for an execution
  // =========================
  app.get(
    "/:id/steps",
    { preHandler: authMiddleware },
    async (req: any, res: any) => {
      try {
        const { id } = req.params

        const rows = await query(
          `SELECT * FROM execution_steps
           WHERE execution_id = $1
           ORDER BY step_index ASC`,
          [id]
        )

        return res.send(rows)
      } catch (err: any) {
        return res.status(500).send({ error: err.message })
      }
    }
  )

  // =========================
  // GET /executions/:id/stream
  // SSE — real-time execution status + steps
  // Polls DB every 1.5 s; closes when terminal status reached
  // =========================
  app.get(
    "/:id/stream",
    { preHandler: authMiddleware },
    async (req: any, reply: any) => {
      const { id } = req.params as { id: string }

      // ── SSE headers ──────────────────────────────────────────────
      reply.raw.setHeader("Content-Type",  "text/event-stream")
      reply.raw.setHeader("Cache-Control", "no-cache")
      reply.raw.setHeader("Connection",    "keep-alive")
      reply.raw.flushHeaders()

      // ── Helper: build state payload from DB ──────────────────────
      const getState = async () => {
        const execRows = await query(
          `SELECT * FROM executions WHERE id = $1`,
          [id]
        )
        if (!execRows.length) return null

        const exec  = execRows[0]
        const steps = await query(
          `SELECT * FROM execution_steps
           WHERE execution_id = $1
           ORDER BY step_index ASC`,
          [id]
        )

        return {
          id:     exec.id,
          status: exec.status,
          steps:  steps.map((s: any) => ({
            id:     s.id,
            name:   s.action,
            status: s.status,
            logs:   s.error ? [s.error] : [],
          })),
        }
      }

      const send = (data: unknown) =>
        reply.raw.write(`data: ${JSON.stringify(data)}\n\n`)

      const TERMINAL = ["completed", "failed", "cancelled"]

      // ── Send initial snapshot immediately ────────────────────────
      try {
        const initial = await getState()
        if (initial) {
          send(initial)
          if (TERMINAL.includes(initial.status)) {
            reply.raw.end()
            return reply
          }
        }
      } catch (_) { /* ignore — first poll might race with creation */ }

      // ── Poll every 1.5 s ─────────────────────────────────────────
      const timer = setInterval(async () => {
        try {
          const state = await getState()
          if (!state) return
          send(state)
          if (TERMINAL.includes(state.status)) {
            clearInterval(timer)
            reply.raw.end()
          }
        } catch {
          clearInterval(timer)
          reply.raw.end()
        }
      }, 1500)

      // ── Clean up when client disconnects ─────────────────────────
      req.raw.on("close", () => clearInterval(timer))

      return reply
    }
  )

}