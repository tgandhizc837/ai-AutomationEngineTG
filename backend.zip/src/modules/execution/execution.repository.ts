import { query } from "../../config/db";

export class ExecutionRepository {

  // =========================
  // ✅ CREATE EXECUTION
  // =========================
  async create(
    testId: string,
    projectId: string,
    workspaceId: string,
    userId: string,
    browser: string = "chromium"
  ) {
    const rows = await query(
      `
      INSERT INTO executions (
        test_id,
        project_id,
        workspace_id,
        user_id,
        browser,
        status,
        created_at,
        updated_at
      )
      VALUES ($1, $2, $3, $4, $5, 'queued', now(), now())
      RETURNING *
      `,
      [testId, projectId, workspaceId, userId, browser]
    );

    return rows[0];
  }

  // =========================
  // ✅ FIND EXECUTION
  // =========================
  async findById(id: string) {
    const rows = await query(
      `SELECT * FROM executions WHERE id = $1`,
      [id]
    );

    return rows[0];
  }

  // =========================
  // ✅ GENERIC STATUS UPDATE
  // =========================
  async updateStatus(
    id: string,
    status: string,
    result?: any
  ) {
    await query(
      `
      UPDATE executions
      SET
        status = $1,
        result = $2,
        updated_at = now()
      WHERE id = $3
      `,
      [status, result ?? null, id]
    );
  }

  // =========================
  // 🚀 MARK RUNNING
  // =========================
  async markRunning(id: string) {
    await query(
      `
      UPDATE executions
      SET
        status = 'running',
        started_at = now(),
        updated_at = now()
      WHERE id = $1
      `,
      [id]
    );
  }

  // =========================
  // ✅ MARK COMPLETED
  // =========================
  async markCompleted(id: string) {
    await query(
      `
      UPDATE executions
      SET
        status = 'completed',
        completed_at = now(),
        updated_at = now()
      WHERE id = $1
      `,
      [id]
    );
  }

  // =========================
  // ❌ MARK FAILED
  // =========================
  async markFailed(
    id: string,
    error?: string
  ) {
    await query(
      `
      UPDATE executions
      SET
        status = 'failed',
        error = $2,
        completed_at = now(),
        updated_at = now()
      WHERE id = $1
      `,
      [id, error ?? null]
    );
  }

  // =========================
  // 🎥 SAVE VIDEO PATH
  // =========================
  async saveVideoPath(id: string, videoUrl: string) {
    await query(
      `
      UPDATE executions
      SET result = COALESCE(result, '{}'::jsonb) || jsonb_build_object('video_url', $2::text),
          updated_at = now()
      WHERE id = $1
      `,
      [id, videoUrl]
    );
  }
}