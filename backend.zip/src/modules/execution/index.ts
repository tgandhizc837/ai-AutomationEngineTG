import { FastifyInstance } from "fastify";
import { ExecutionRepo } from "../../repositories/ExecutionRepo.js";
import { spawn } from "child_process";

export default async function executionModule(app: FastifyInstance) {

  app.post("/executions", async (req) => {
    const { workspaceId, testId } = req.body as any;

    const execution = await ExecutionRepo.create(workspaceId, testId);

    spawn("node", [
      "dist/queue/executionWorker.js",
      execution.id
    ]);

    return execution;
  });

  app.get("/executions/:id", async (req) => {
    const { id } = req.params as any;
    return ExecutionRepo.findById(id);
  });
}