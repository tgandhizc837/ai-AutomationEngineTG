import { FastifyInstance } from "fastify";
import { supabase } from "../../config/supabase.js";

export default async function billingModule(app: FastifyInstance) {

  app.get("/billing/:workspaceId", async (req) => {
    const { workspaceId } = req.params as any;

    const { data, error } = await supabase
      .from("llm_usage")
      .select("prompt_tokens, completion_tokens, cost_usd")
      .eq("workspace_id", workspaceId);

    if (error) throw error;

    const summary = data.reduce(
      (acc: any, row: any) => {
        acc.tokens += row.prompt_tokens + row.completion_tokens;
        acc.cost += row.cost_usd;
        return acc;
      },
      { tokens: 0, cost: 0 }
    );

    return summary;
  });
}