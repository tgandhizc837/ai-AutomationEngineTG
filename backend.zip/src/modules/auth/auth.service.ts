import bcrypt from "bcrypt"
import jwt from "jsonwebtoken"
import * as authRepository from "./auth.repository"

const JWT_SECRET = process.env.JWT_SECRET!

export async function login(email: string, password: string) {
  const cleanEmail = email.trim().toLowerCase()
  const cleanPassword = password.trim()

  console.log("🔐 Login attempt:", { email: cleanEmail })

  const user = await authRepository.findByEmail(cleanEmail)

  if (!user) {
    console.log("❌ User not found")
    return null
  }

  const isValid = await bcrypt.compare(
    cleanPassword,
    user.password_hash
  )

  if (!isValid) {
    console.log("❌ Invalid password")
    return null
  }

  console.log("✅ Login successful:", user.id)

  // ✅ ONLY include userId in token
  const token = jwt.sign(
    {
      userId: user.id
    },
    JWT_SECRET,
    { expiresIn: "1d" }
  )

  return {
    token,
    user: {
      id: user.id,
      email: user.email,
      name: user.name
    }
  }
}