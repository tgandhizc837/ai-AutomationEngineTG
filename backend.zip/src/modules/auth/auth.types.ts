export interface AuthUser {
  id: string
  workspaceId: string
}