import { FastifyRequest, FastifyReply } from "fastify"
import { login } from "./auth.service"

type LoginBody = {
  email: string
  password: string
}

export async function loginHandler(
  req: FastifyRequest<{ Body: LoginBody }>,
  reply: FastifyReply
) {
  try {
    const { email, password } = req.body

    const result = await login(email, password)

    if (!result) {
      return reply.status(401).send({
        message: "Invalid email or password"
      })
    }

    // ✅ store JWT (not user.id)
    reply.setCookie("token", result.token, {
      httpOnly: true,
      secure: false, // true in production (HTTPS)
      sameSite: "lax",
      path: "/"
    })

    return reply.send({ user: result.user })

  } catch (err) {
    console.error("LOGIN ERROR:", err)
    return reply.status(500).send({ message: "Server error" })
  }
}