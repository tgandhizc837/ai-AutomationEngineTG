import { FastifyInstance } from "fastify"
import * as authController from "./auth.controller"
import { loginSchema } from "./auth.schema"
import { authMiddleware } from "./auth.middleware"
import { findById } from "./auth.repository"
import { query } from "../../config/db"
import bcrypt from "bcrypt"
import jwt from "jsonwebtoken"

export default async function authRoutes(app: FastifyInstance) {

  // =========================
  // POST /auth/signup
  // =========================
  app.post("/signup", async (req: any, reply) => {
    try {
      const { name, email, password, org_name } = req.body as {
        name: string; email: string; password: string; org_name: string
      }

      if (!name?.trim())     return reply.status(400).send({ message: "Name is required" })
      if (!email?.trim())    return reply.status(400).send({ message: "Email is required" })
      if (!password)         return reply.status(400).send({ message: "Password is required" })
      if (!org_name?.trim()) return reply.status(400).send({ message: "Organisation name is required" })

      const cleanEmail = email.trim().toLowerCase()

      // Check if email already taken
      const existing = await query("SELECT id FROM users WHERE LOWER(email) = $1", [cleanEmail])
      if (existing.length) return reply.status(409).send({ message: "Email already in use" })

      // Find or create workspace by org name (case-insensitive slug match)
      const slug = org_name.trim().toLowerCase().replace(/\s+/g, "-")
      let workspace: any = null

      const ws = await query("SELECT * FROM workspaces WHERE LOWER(name) = LOWER($1) LIMIT 1", [org_name.trim()])
      if (ws.length) {
        workspace = ws[0]
        console.log(`✅ [Signup] Joining existing workspace: ${workspace.id} (${workspace.name})`)
      } else {
        const created = await query(
          "INSERT INTO workspaces(name, slug, plan) VALUES($1, $2, 'free') RETURNING *",
          [org_name.trim(), slug]
        )
        workspace = created[0]
        console.log(`✅ [Signup] Created new workspace: ${workspace.id} (${workspace.name})`)
      }

      // Hash password
      const password_hash = await bcrypt.hash(password, 10)

      // Create user linked to workspace
      const userRows = await query(
        "INSERT INTO users(name, email, password_hash, workspace_id) VALUES($1,$2,$3,$4) RETURNING id, name, email, workspace_id",
        [name.trim(), cleanEmail, password_hash, workspace.id]
      )
      const user = userRows[0]

      // Issue JWT
      const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET!, { expiresIn: "1d" })

      reply.setCookie("token", token, {
        httpOnly: true,
        secure: false,
        sameSite: "lax",
        path: "/"
      })

      console.log(`✅ [Signup] User created: ${user.email} → workspace ${workspace.name}`)

      return reply.status(201).send({
        user: { id: user.id, name: user.name, email: user.email, workspace_id: workspace.id }
      })
    } catch (err: any) {
      console.error("❌ [Signup] Error:", err.message)
      return reply.status(500).send({ message: "Signup failed: " + err.message })
    }
  })

  app.post(
    "/login",
    { schema: loginSchema },
    authController.loginHandler
  )

  app.get(
    "/me",
    { preHandler: authMiddleware },
    async (req: any, reply) => {
      // Pull the full user row from DB so we get workspace_id
      const dbUser = await findById(req.user.id)
      console.log("🧑 [/auth/me] DB user row:", dbUser)

      if (!dbUser) {
        return reply.status(401).send({ message: "User not found" })
      }

      // ── Resolve workspace_id ──────────────────────────────────────
      // Priority 1: workspace_id column on the user row (set at signup)
      let workspaceId: string | null = dbUser.workspace_id ?? null
      console.log("🔑 [/auth/me] P1 workspace_id from user row:", workspaceId)

      // Priority 2: look up any workspace in the system
      if (!workspaceId) {
        const fromWorkspace = await query(
          `SELECT id FROM workspaces ORDER BY created_at ASC LIMIT 1`,
          []
        )
        workspaceId = fromWorkspace[0]?.id ?? null
        console.log("🔑 [/auth/me] P2 workspace_id from workspaces table:", workspaceId)
      }

      // Priority 3: auto-create a default workspace (first-run / no workspace exists)
      if (!workspaceId) {
        console.log("🏗️  [/auth/me] No workspace found — auto-creating default workspace")
        const created = await query(
          `INSERT INTO workspaces(name, plan) VALUES($1,$2) RETURNING id`,
          ["Default Workspace", "free"]
        )
        workspaceId = created[0]?.id ?? null
        console.log("✅ [/auth/me] Auto-created workspace:", workspaceId)
      }

      console.log("📤 [/auth/me] Sending workspace_id:", workspaceId)
      return reply.send({
        user: {
          id:           dbUser.id,
          email:        dbUser.email,
          name:         dbUser.name,
          workspace_id: workspaceId,
        }
      })
    }
  )
}