import { query } from "../../config/db"

export async function findByEmail(email: string) {
  const users = await query(
    "SELECT * FROM users WHERE LOWER(email) = LOWER($1)",
    [email]
  )
  return users[0] || null
}

export async function findById(id: string) {
  const users = await query(
    "SELECT * FROM users WHERE id = $1",
    [id]
  )
  return users[0] || null
}