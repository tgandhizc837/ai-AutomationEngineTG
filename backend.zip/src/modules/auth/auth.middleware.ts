import { FastifyRequest, FastifyReply } from "fastify";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET!;

export async function authMiddleware(
  req: FastifyRequest,
  reply: FastifyReply
) {
  try {
    console.log("🔐 [Middleware] Checking auth");

    const token = req.cookies?.token;

    console.log("🍪 [Middleware] Token present:", !!token);

    if (!token) {
      console.log("❌ [Middleware] No token found");
      return reply.status(401).send({
        message: "Not authenticated",
      });
    }

    // 🔍 verify token
    const decoded: any = jwt.verify(token, JWT_SECRET);

    console.log("✅ [Middleware] Token decoded:", decoded);

    // ✅ attach ONLY userId
    (req as any).user = {
      id: decoded.userId,
    };

    console.log("👤 [Middleware] User attached:", (req as any).user);

  } catch (err: any) {
    console.log("💥 [Middleware] Token error:", err.message);

    return reply.status(401).send({
      message: "Invalid token",
    });
  }
}