import { query } from "../../config/db"

export default async function healingRoutes(app:any){

  app.get("/", async ()=>{
    return await query(
      "SELECT * FROM healing_events ORDER BY created_at DESC"
    )
  })

}