import { FastifyInstance } from "fastify";
import { supabase } from "../../config/supabase.js";

export default async function healingModule(app: FastifyInstance) {

  app.get("/healing/:executionStepId", async (req) => {
    const { executionStepId } = req.params as any;

    const { data, error } = await supabase
      .from("healing_events")
      .select("*")
      .eq("execution_step_id", executionStepId);

    if (error) throw error;
    return data;
  });
}