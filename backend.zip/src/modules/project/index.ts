import { FastifyInstance } from "fastify";
import { ProjectRepo } from "../../repositories/ProjectRepo.js";

export default async function projectModule(app: FastifyInstance) {

  app.post("/projects", async (req) => {

    const { workspaceId, name } = req.body as any;

    return ProjectRepo.create(workspaceId, name);

  });

  app.get("/projects/:workspaceId", async (req) => {

    const { workspaceId } = req.params as any;

    return ProjectRepo.findByWorkspace(workspaceId);

  });

  app.get("/project/:id", async (req) => {

    const { id } = req.params as any;

    return ProjectRepo.findById(id);

  });

  app.delete("/project/:id", async (req) => {

    const { id } = req.params as any;

    await ProjectRepo.delete(id);

    return { success: true };

  });

}