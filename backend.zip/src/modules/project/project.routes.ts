import { authMiddleware } from "../auth/auth.middleware"
import { query } from "../../config/db"

export default async function projectRoutes(app: any) {

  // =========================
  // GET /projects?workspace_id=X
  // List projects for a workspace (scoped to the logged-in user)
  // =========================
  app.get(
    "/",
    { preHandler: authMiddleware },
    async (req: any, res: any) => {
      try {
        const { workspace_id } = req.query

        console.log("📋 [GET /projects] workspace_id:", workspace_id)

        if (!workspace_id) {
          return res.status(400).send({ error: "workspace_id is required" })
        }

        const rows = await query(
          `SELECT * FROM projects WHERE workspace_id = $1 ORDER BY created_at DESC`,
          [workspace_id]
        )

        console.log(`✅ [GET /projects] Found ${rows.length} project(s) for workspace ${workspace_id}`)
        return res.send(rows)
      } catch (err: any) {
        console.error("❌ [GET /projects] Error:", err.message)
        return res.status(500).send({ error: err.message })
      }
    }
  )

  // =========================
  // POST /projects
  // Create a new project
  // =========================
  app.post(
    "/",
    { preHandler: authMiddleware },
    async (req: any, res: any) => {
      try {
        const { workspace_id, name, base_url } = req.body

        console.log("🆕 [POST /projects] Incoming body:", { workspace_id, name, base_url })

        if (!workspace_id) {
          console.warn("⚠️  [POST /projects] Missing workspace_id")
          return res.status(400).send({ error: "workspace_id is required" })
        }
        if (!name) {
          console.warn("⚠️  [POST /projects] Missing name")
          return res.status(400).send({ error: "name is required" })
        }

        const rows = await query(
          `INSERT INTO projects(workspace_id, name, base_url)
           VALUES($1, $2, $3)
           RETURNING *`,
          [workspace_id, name, base_url ?? null]
        )

        const created = rows[0]
        console.log("✅ [POST /projects] Project created:", {
          id:           created.id,
          name:         created.name,
          workspace_id: created.workspace_id,
          base_url:     created.base_url,
          created_at:   created.created_at,
        })

        return res.status(201).send(created)
      } catch (err: any) {
        console.error("❌ [POST /projects] DB error:", err.message)
        return res.status(500).send({ error: err.message })
      }
    }
  )

}