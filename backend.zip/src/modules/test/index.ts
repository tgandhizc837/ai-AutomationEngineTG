import { FastifyInstance } from "fastify";
import { supabase } from "../../config/supabase.js";

export default async function testModule(app: FastifyInstance) {

  app.post("/tests", async (req) => {
    const { workspaceId, projectId, name, gherkin } = req.body as any;

    const { data, error } = await supabase
      .from("tests")
      .insert({
        workspace_id: workspaceId,
        project_id: projectId,
        name,
        gherkin
      })
      .select()
      .single();

    if (error) throw error;

    return data;
  });

  app.get("/tests/:projectId", async (req) => {
    const { projectId } = req.params as any;

    const { data, error } = await supabase
      .from("tests")
      .select("*")
      .eq("project_id", projectId);

    if (error) throw error;

    return data;
  });

  app.put("/tests/:id", async (req) => {
    const { id } = req.params as any;
    const { gherkin, name } = req.body as any;

    const { data, error } = await supabase
      .from("tests")
      .update({ gherkin, name })
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;

    return data;
  });

  app.delete("/tests/:id", async (req) => {
    const { id } = req.params as any;

    const { error } = await supabase
      .from("tests")
      .delete()
      .eq("id", id);

    if (error) throw error;

    return { success: true };
  });
}