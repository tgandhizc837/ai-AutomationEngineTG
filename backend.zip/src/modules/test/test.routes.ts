import { authMiddleware } from "../auth/auth.middleware"
import { query } from "../../config/db"

export default async function testRoutes(app: any) {

  // =========================
  // GET /tests?project_id=X
  // List tests for a project
  // =========================
  app.get(
    "/",
    { preHandler: authMiddleware },
    async (req: any, res: any) => {
      try {
        const { project_id } = req.query

        if (!project_id) {
          return res.status(400).send({ error: "project_id is required" })
        }

        const rows = await query(
          `SELECT * FROM tests
           WHERE project_id = $1
           ORDER BY created_at DESC`,
          [project_id]
        )

        return res.send(rows)
      } catch (err: any) {
        return res.status(500).send({ error: err.message })
      }
    }
  )

  // =========================
  // POST /tests
  // Create a new test with Gherkin content
  // =========================
  app.post(
    "/",
    { preHandler: authMiddleware },
    async (req: any, res: any) => {
      try {
        const { project_id, name, gherkin } = req.body

        if (!project_id) return res.status(400).send({ error: "project_id is required" })
        if (!name)       return res.status(400).send({ error: "name is required" })
        if (!gherkin)    return res.status(400).send({ error: "gherkin is required" })

        const rows = await query(
          `INSERT INTO tests(project_id, name, gherkin)
           VALUES($1, $2, $3)
           RETURNING *`,
          [project_id, name, gherkin]
        )

        return res.status(201).send(rows[0])
      } catch (err: any) {
        return res.status(500).send({ error: err.message })
      }
    }
  )

}