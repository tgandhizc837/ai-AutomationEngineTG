import { authMiddleware } from "../auth/auth.middleware";
import { openai } from "../../config/openai";
import * as XLSX from "xlsx";

/**
 * Fuzzy column picker.
 *
 * Strategy (in priority order):
 *   1. Exact match (case-insensitive, trimmed)
 *   2. The row's column header *contains* one of the alias keywords
 *   3. One of the alias keywords *contains* the row's column header
 *
 * This means a column called "Test Summary", "Test_Name", "DESCRIPTION",
 * "Action Steps", "Acceptance Criteria", etc. will all be found.
 */
function pick(row: Record<string, any>, ...aliases: string[]): string {
  const rowKeys = Object.keys(row);
  const normalise = (s: string) => s.trim().toLowerCase().replace(/[^a-z0-9]/g, "");

  // Pass 1 – exact match (normalised)
  for (const alias of aliases) {
    const na = normalise(alias);
    const found = rowKeys.find((rk) => normalise(rk) === na);
    if (found && row[found] != null) return String(row[found]).trim();
  }

  // Pass 2 – column header contains alias keyword
  for (const alias of aliases) {
    const na = normalise(alias);
    const found = rowKeys.find((rk) => normalise(rk).includes(na));
    if (found && row[found] != null) return String(row[found]).trim();
  }

  // Pass 3 – alias keyword contains column header
  for (const alias of aliases) {
    const na = normalise(alias);
    const found = rowKeys.find((rk) => na.includes(normalise(rk)) && normalise(rk).length >= 3);
    if (found && row[found] != null) return String(row[found]).trim();
  }

  return "";
}

export default async function excelImportRoutes(app: any) {
  // =====================================================
  // POST /tests/import-excel
  // Accepts: multipart/form-data with field "file"
  // Returns: { results: Array<{ name, gherkin }> }
  // =====================================================
  app.post(
    "/import-excel",
    { preHandler: authMiddleware },
    async (req: any, res: any) => {
      try {
        const data = await req.file();

        if (!data) {
          return res.status(400).send({ error: "No file uploaded" });
        }

        const mimetype: string = data.mimetype || "";
        const filename: string = (data.filename || "").toLowerCase();
        const isExcel =
          mimetype.includes("spreadsheetml") ||
          mimetype.includes("excel") ||
          mimetype.includes("octet-stream") ||
          filename.endsWith(".xlsx") ||
          filename.endsWith(".xls") ||
          filename.endsWith(".csv");

        if (!isExcel) {
          return res
            .status(400)
            .send({ error: "Please upload a valid Excel (.xlsx / .xls) or CSV file" });
        }

        // Collect stream into buffer
        const chunks: Buffer[] = [];
        for await (const chunk of data.file) {
          chunks.push(chunk);
        }
        const buffer = Buffer.concat(chunks);

        // Parse workbook
        const workbook = XLSX.read(buffer, { type: "buffer" });
        const sheetName = workbook.SheetNames[0];
        if (!sheetName) {
          return res.status(400).send({ error: "Excel file has no sheets" });
        }
        const sheet = workbook.Sheets[sheetName];
        const rows: Record<string, any>[] = XLSX.utils.sheet_to_json(sheet, {
          defval: "",
        });

        if (rows.length === 0) {
          return res.status(400).send({ error: "No data rows found in the Excel file" });
        }

        // Validate that at least one "summary-like" column exists using the same fuzzy strategy
        const firstRow = rows[0];
        const normalise = (s: string) => s.trim().toLowerCase().replace(/[^a-z0-9]/g, "");
        const summaryKeywords = ["summary", "title", "testcase", "testname", "testtitle",
          "name", "description", "desc", "scenario", "subject", "testid", "casename"];
        const detectedColumns = Object.keys(firstRow);

        const hasSummary = detectedColumns.some((col) => {
          const nc = normalise(col);
          return summaryKeywords.some(
            (kw) => nc === kw || nc.includes(kw) || kw.includes(nc)
          );
        });

        if (!hasSummary) {
          return res.status(400).send({
            error:
              `Could not find a test name/summary column. Columns detected: [${detectedColumns.join(", ")}]. ` +
              `Expected one of: Summary, Title, Description, Test Name, Test Case, Test Summary, Name, Scenario.`,
          });
        }

        // Convert each row to Gherkin via LLM
        const results: { name: string; gherkin: string }[] = [];

        for (const row of rows) {
          // Summary — many aliases
          const summary = pick(
            row,
            "Summary", "Test Summary", "Test Name", "Test Title", "Test Case",
            "Title", "Name", "Description", "Desc", "Scenario", "Subject",
            "Case Name", "Case Title", "TC Summary"
          );
          if (!summary) continue; // skip blank rows

          // Pre-requisite
          const preRequisite = pick(
            row,
            "Pre Requisite", "Pre-Requisite", "Prerequisite", "Pre Condition",
            "Precondition", "Pre-condition", "Setup", "Preconditions", "Prerequisites"
          );

          // Test steps — "steps", "actions", "procedure", etc.
          const testSteps = pick(
            row,
            "Test Steps", "Test Step", "Steps", "Step", "Actions", "Action",
            "Procedure", "Test Actions", "Steps to Reproduce", "Steps To Execute",
            "Execution Steps", "Test Procedure", "Instructions"
          );

          // Test data
          const testData = pick(
            row,
            "Test Data", "Data", "Input", "Input Data", "Test Input",
            "Parameters", "Values", "Test Values"
          );

          // Expected result
          const expectedResult = pick(
            row,
            "Expected Result", "Expected", "Expected Output", "Result",
            "Expected Behavior", "Expected Behaviour", "Acceptance Criteria",
            "Pass Criteria", "Outcome", "Expected Outcome", "Validation"
          );

          const prompt = `Convert the following manual test case into Gherkin BDD format.
Use proper Feature, Scenario, Given, When, Then, And keywords.
Return ONLY the Gherkin text — no markdown code fences, no extra explanation.

Summary / Title: ${summary}
Pre-Requisite: ${preRequisite || "None"}
Test Steps:
${testSteps || "Not specified"}
Test Data: ${testData || "None"}
Expected Result: ${expectedResult || "Not specified"}`;

          const response = await openai.chat.completions.create({
            model: process.env.PLANNING_MODEL || "gpt-4o-mini",
            messages: [
              {
                role: "system",
                content:
                  "You are a senior QA engineer. Convert manual test cases to clean, actionable Gherkin BDD scenarios. Use concrete step text derived from the test steps provided.",
              },
              { role: "user", content: prompt },
            ],
            temperature: 0.1,
          });

          const gherkin =
            (response.choices[0].message.content || "").trim();

          results.push({ name: summary, gherkin });
        }

        return res.send({ results });
      } catch (err: any) {
        app.log.error(err);
        return res.status(500).send({ error: err.message });
      }
    }
  );
}
