import { FastifyInstance } from "fastify";
import { supabase } from "../../config/supabase.js";

export default async function llmModule(app: FastifyInstance) {

  app.get("/llm-usage/:workspaceId", async (req) => {
    const { workspaceId } = req.params as any;

    const { data, error } = await supabase
      .from("llm_usage")
      .select("*")
      .eq("workspace_id", workspaceId);

    if (error) throw error;
    return data;
  });
}