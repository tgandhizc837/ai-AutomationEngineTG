import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { WorkspaceRepo } from "../repositories/WorkspaceRepo.js";

interface CreateWorkspaceBody {
  name: string;
  plan: string;
}

export default async function workspaceRoutes(fastify: FastifyInstance) {

  // Create workspace
  fastify.post(
    "/workspaces",
    async (
      request: FastifyRequest<{ Body: CreateWorkspaceBody }>,
      reply: FastifyReply
    ) => {
      try {
        const { name, plan } = request.body;

        if (!name || !plan) {
          return reply.status(400).send({
            error: "name and plan are required"
          });
        }

        const workspace = await WorkspaceRepo.create(name, plan);

        return reply.status(201).send(workspace);
      } catch (error) {
        request.log.error(error);
        return reply.status(500).send({
          error: "Failed to create workspace"
        });
      }
    }
  );

  // Get all workspaces
  fastify.get("/workspaces", async (_request, reply) => {
    try {
      const workspaces = await WorkspaceRepo.findAll();
      return reply.send(workspaces);
    } catch (error) {
      return reply.status(500).send({
        error: "Failed to fetch workspaces"
      });
    }
  });

  // Get workspace by ID
  fastify.get(
    "/workspaces/:id",
    async (
      request: FastifyRequest<{ Params: { id: string } }>,
      reply: FastifyReply
    ) => {
      try {
        const workspace = await WorkspaceRepo.findById(request.params.id);

        if (!workspace) {
          return reply.status(404).send({
            error: "Workspace not found"
          });
        }

        return reply.send(workspace);
      } catch (error) {
        return reply.status(500).send({
          error: "Failed to fetch workspace"
        });
      }
    }
  );

  // Delete workspace
  fastify.delete(
    "/workspaces/:id",
    async (
      request: FastifyRequest<{ Params: { id: string } }>,
      reply: FastifyReply
    ) => {
      try {
        await WorkspaceRepo.delete(request.params.id);

        return reply.send({
          message: "Workspace deleted"
        });
      } catch (error) {
        return reply.status(500).send({
          error: "Failed to delete workspace"
        });
      }
    }
  );
}
