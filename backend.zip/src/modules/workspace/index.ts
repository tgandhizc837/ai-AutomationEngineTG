import { FastifyInstance } from "fastify";
import { WorkspaceRepo } from "../../repositories/WorkspaceRepo.js";

export default async function workspaceModule(app: FastifyInstance) {

  app.post("/workspaces", async (req) => {
    const { name, plan } = req.body as any;

    return WorkspaceRepo.create(name, plan);
  });

  app.get("/workspaces", async () => {
    return WorkspaceRepo.findAll();
  });

  app.get("/workspaces/:id", async (req) => {
    const { id } = req.params as any;
    return WorkspaceRepo.findById(id);
  });

  app.delete("/workspaces/:id", async (req) => {
    const { id } = req.params as any;

    await WorkspaceRepo.delete(id);

    return { success: true };
  });

}