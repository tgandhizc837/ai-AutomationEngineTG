import { pool } from "../../config/db.js";
import { CreateWorkspaceInput } from "./workspace.schema.js";

export async function createWorkspace(data: CreateWorkspaceInput) {

  const result = await pool.query(
    "INSERT INTO workspaces(name, plan) VALUES($1,$2) RETURNING *",
    [data.name, data.plan]
  );

  return result.rows[0];
}

export async function getAllWorkspaces() {

  const result = await pool.query(
    "SELECT * FROM workspaces"
  );

  return result.rows;
}

export async function getWorkspaceById(id: string) {

  const result = await pool.query(
    "SELECT * FROM workspaces WHERE id=$1",
    [id]
  );

  return result.rows[0];
}

export async function deleteWorkspace(id: string) {

  await pool.query(
    "DELETE FROM workspaces WHERE id=$1",
    [id]
  );

  return { success: true };
}