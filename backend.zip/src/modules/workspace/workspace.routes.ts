import { FastifyInstance } from "fastify";
import { query } from "../../config/db.js";

export default async function workspaceModule(app: FastifyInstance) {

  app.post("/workspaces", async (req, reply) => {
    const { name, plan } = req.body as { name: string; plan: string };

    try {
      const result = await query(
        "INSERT INTO workspaces(name, plan) VALUES($1, $2) RETURNING *",
        [name, plan]
      );

      reply.code(201);
      return result[0];

    } catch (error) {
      reply.code(500);
      throw error;
    }
  });

  app.get("/workspaces", async () => {
    return await query("SELECT * FROM workspaces");
  });

  app.get("/workspaces/:id", async (req, reply) => {
    const { id } = req.params as { id: string };

    const result = await query(
      "SELECT * FROM workspaces WHERE id = $1",
      [id]
    );

    if (result.length === 0) {
      reply.code(404);
      return { error: "Workspace not found" };
    }

    return result[0];
  });

  app.delete("/workspaces/:id", async (req) => {
    const { id } = req.params as { id: string };

    await query("DELETE FROM workspaces WHERE id = $1", [id]);

    return { success: true };
  });
}