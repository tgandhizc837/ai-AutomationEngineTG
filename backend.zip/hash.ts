import bcrypt from "bcrypt"

async function generate() {
  const hash = await bcrypt.hash("Admin5674", 10)
  console.log(hash)
}

generate()