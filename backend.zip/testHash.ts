import bcrypt from "bcrypt"

const hash = "$2b$10$fiPDG1dYzhGR3zLUE/LG8u4XFu2mv5st7qryP7oBDkFGsiI0GwPa2"

async function test() {
  const result = await bcrypt.compare("Admin123!", hash)
  console.log("Match:", result)
}

test()