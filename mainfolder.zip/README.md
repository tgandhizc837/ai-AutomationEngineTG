# AI Test Engine

An AI-powered, self-healing test automation platform built as a SaaS product. It lets teams write plain-language BDD scenarios and have an LLM-driven engine plan, execute, and automatically repair them against any web application — all from a multi-tenant dashboard.

---

## Table of Contents

- [What This Product Does](#what-this-product-does)
- [Architecture Overview](#architecture-overview)
- [Monorepo Structure](#monorepo-structure)
- [Key Concepts](#key-concepts)
- [Tech Stack](#tech-stack)
- [Getting Started](#getting-started)
- [Environment Variables](#environment-variables)
- [Running the Project](#running-the-project)
- [Writing Tests](#writing-tests)
- [How AI Healing Works](#how-ai-healing-works)
- [Billing & Cost Control](#billing--cost-control)

---

## What This Product Does

| Capability | Description |
|---|---|
| **Natural-language test authoring** | Write Cucumber `.feature` files with plain steps like `I click "Login"` or `I enter "…" into "Email address"` |
| **AI-driven step execution** | A planning agent converts each step into a concrete browser action using an LLM, with no hard-coded selectors |
| **Self-healing** | When a locator breaks, a healing agent finds an equivalent element using DOM semantics, embeddings, and vector memory — without human intervention |
| **Multi-tenant workspaces** | Every team gets its own workspace, projects, environments, and test library |
| **Real-time execution dashboard** | Watch step-by-step execution status, timelines, screenshots, and logs in the frontend |
| **LLM cost tracking** | Every LLM call is metered; a BudgetGuard enforces per-run spending limits |

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                        Frontend (Next.js)                    │
│  Dashboard · Projects · Tests · Executions · Billing UI     │
└───────────────────────┬─────────────────────────────────────┘
                        │ REST / React Query
┌───────────────────────▼─────────────────────────────────────┐
│                      Backend (Fastify API)                    │
│  Auth · Workspace · Project · Test · Execution · Billing     │
│                                                              │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              Orchestration Layer                       │  │
│  │  ExecutionOrchestrator → StepRunner → ModelRouter     │  │
│  │  BudgetGuard (enforces LLM spend limits)              │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌────────────── AI Agents ──────────────────────────────┐  │
│  │  PlanningAgent   – step → browser action plan         │  │
│  │  ResolutionAgent – resolve ambiguous locators         │  │
│  │  HealingAgent    – repair broken selectors            │  │
│  │  SimilarityEngine– embedding-based element matching   │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  BullMQ Job Queue  ──►  Execution Worker                     │
└───────────────────────┬─────────────────────────────────────┘
                        │ BullMQ / Redis
┌───────────────────────▼─────────────────────────────────────┐
│                     Engine (Playwright + Cucumber)           │
│  intentParser · executor · browserManager · testEngine       │
│  AI sub-modules: dom · planner · ranking · embedding ·       │
│                  memory · healing · resolution               │
└─────────────────────────────────────────────────────────────┘
              │                         │
        PostgreSQL                    Redis
     (data persistence)          (queue + cache)
```

---

## Monorepo Structure

```
ai-test-engine/
│
├── backend/            ← Fastify REST API + AI agents + orchestration
├── engine/             ← Playwright test runner + Cucumber + LLM integration
├── frontend/           ← Next.js 14 dashboard (SaaS UI)
├── src/
│   └── redisClient.ts  ← Shared Redis client
├── package.json        ← Root scripts (runs all services with concurrently)
└── README.md
```

### `backend/`

The core API and AI brain of the platform.

```
backend/src/
│
├── server.ts                   ← Fastify server entry point
├── app.ts                      ← Plugin registration
│
├── config/
│   ├── env.ts                  ← Environment variable loading
│   ├── db.ts                   ← PostgreSQL connection
│   ├── redis.ts                ← Redis connection
│   ├── openai.ts               ← OpenAI client
│   └── bullmq.ts               ← BullMQ setup
│
├── modules/                    ← Feature modules (REST routes + business logic)
│   ├── auth/                   ← JWT-based authentication
│   ├── workspace/              ← Tenant workspace management
│   ├── project/                ← Projects within a workspace
│   ├── environment/            ← Test environments (base URLs, secrets)
│   ├── test/                   ← Test case CRUD
│   ├── suite/                  ← Test suite grouping
│   ├── execution/              ← Trigger and monitor test runs
│   ├── healing/                ← Healing history and overrides
│   ├── llm/                    ← LLM usage log endpoints
│   └── billing/                ← Plans, usage, upgrade flow
│
├── agents/
│   ├── PlanningAgent.ts        ← Converts natural-language steps into action plans
│   ├── ResolutionAgent.ts      ← Resolves ambiguous or multi-match locators
│   ├── HealingAgent.ts         ← Repairs broken selectors post-failure
│   └── SimilarityEngine.ts     ← Embedding-based element similarity scoring
│
├── orchestration/
│   ├── ExecutionOrchestrator.ts← Top-level run coordinator
│   ├── StepRunner.ts           ← Executes individual steps via the engine
│   ├── ModelRouter.ts          ← Selects the right LLM model per task type
│   └── BudgetGuard.ts          ← Aborts run if LLM cost limit is exceeded
│
├── queue/
│   ├── jobQueue.ts             ← BullMQ queue definition
│   └── executionWorker.ts      ← Worker that processes queued execution jobs
│
├── repositories/
│   ├── WorkspaceRepo.ts        ← Workspace DB queries
│   ├── ExecutionRepo.ts        ← Execution + step lifecycle queries
│   ├── LocatorMemoryRepo.ts    ← Vector memory for healed locators
│   └── LlmUsageRepo.ts         ← Per-run LLM token/cost records
│
├── utils/
│   ├── hash.ts                 ← Password hashing (bcrypt)
│   ├── logger.ts               ← Pino structured logger
│   └── metrics.ts              ← Performance metrics helpers
│
└── types/
    └── index.ts                ← Shared TypeScript domain types
```

### `engine/`

The test execution runtime. Receives jobs from the backend queue and runs them via Playwright.

```
engine/src/
│
├── core/
│   ├── testEngine.ts           ← Main engine entry point
│   ├── executor.ts             ← Runs a planned action in the browser
│   ├── browserManager.ts       ← Playwright browser lifecycle
│   └── intentParser.ts        ← Parses step intent before planning
│
├── ai/
│   ├── dom/
│   │   ├── semanticExtractor.ts← Extracts semantic labels from live DOM
│   │   ├── labelResolver.ts    ← Maps natural-language labels to DOM nodes
│   │   ├── menuTreeBuilder.ts  ← Builds navigable menu trees for navigation steps
│   │   └── semanticTypes.ts    ← Shared DOM semantic type definitions
│   │
│   ├── planner/
│   │   ├── llmPlanner.ts       ← Calls LLM to produce an action plan for a step
│   │   └── actionSchema.ts     ← Zod schema for validated action objects
│   │
│   ├── ranking/
│   │   └── scoringEngine.ts    ← Scores candidate elements for best match
│   │
│   ├── embedding/
│   │   └── embeddingService.ts ← Generates vector embeddings for elements/labels
│   │
│   ├── memory/
│   │   └── locatorMemory.ts    ← Stores and retrieves healed locators from DB
│   │
│   ├── healing/                ← Healing pipeline for broken selectors
│   ├── resolution/             ← Multi-match resolution logic
│   └── similarity/             ← Cosine/vector similarity utilities
│
├── selector/
│   └── basicLocator.ts         ← Fallback CSS/XPath locator strategies
│
├── hooks/
│   └── hooks.ts                ← Cucumber Before/After hooks
│
├── features/
│   ├── login.feature           ← Example BDD login scenario
│   └── bhavin.feature          ← Additional feature example
│
└── reports/                    ← JSON execution reports (auto-generated)
```

### `frontend/`

Next.js 14 App Router SaaS dashboard.

```
frontend/src/
│
├── app/
│   ├── (auth)/login & signup   ← Authentication pages
│   └── dashboard/
│       ├── page.tsx            ← KPI overview dashboard
│       ├── projects/           ← Project list & detail
│       │   └── [projectId]/tests/[testId]/execution/[executionId]/
│       ├── executions/         ← All executions view
│       ├── billing/            ← Plan + usage
│       └── settings/           ← Workspace settings
│
├── components/
│   ├── layout/                 ← AppShell, Sidebar, TopNavbar, WorkspaceSwitcher
│   ├── dashboard/              ← KPIGrid, ExecutionTrendChart, SuccessRateChart
│   ├── projects/               ← ProjectCard, ProjectGrid, CreateProjectModal
│   ├── tests/                  ← TestTable, TestEditor, RunTestButton
│   ├── execution/              ← StepTimeline, StepDetailPanel, ExecutionStatusBadge
│   ├── billing/                ← PlanCard, UsageChart, UpgradeModal
│   └── ui/                     ← Reusable design system (Button, Badge, Modal, Table…)
│
├── hooks/                      ← useWorkspace, useProjects, useTests, useExecutions,
│                                   useExecutionLive (real-time polling)
├── lib/                        ← api.ts, queryClient.ts, auth.ts, constants.ts
└── types/                      ← project.ts, test.ts, execution.ts
```

---

## Key Concepts

### AI Agents

| Agent | Role |
|---|---|
| `PlanningAgent` | Given a plain-English step (`I click "Login"`), asks the LLM to produce a structured action (selector strategy, target label, action type) |
| `ResolutionAgent` | When multiple DOM elements match a label, asks the LLM to choose the best one given context |
| `HealingAgent` | After a locator failure, re-scans the DOM, generates embeddings, and finds a semantically equivalent element |
| `SimilarityEngine` | Uses vector embeddings to rank candidate elements by semantic distance from the intended target |

### Orchestration

- `ExecutionOrchestrator` — coordinates the full test run: fetch steps, dispatch to `StepRunner`, persist results
- `StepRunner` — executes one step at a time, routing through `ModelRouter` to pick the cheapest capable model
- `BudgetGuard` — checks cumulative token spend before every LLM call; aborts if the per-run budget is exceeded

### Queue Architecture

Executions are decoupled from the API via **BullMQ + Redis**:

```
POST /executions  →  jobQueue  →  executionWorker  →  engine
```

This allows multiple workers to process runs in parallel without blocking the API.

### Locator Memory (Self-Healing)

When a healed locator is found, it is stored in `LocatorMemoryRepo` as a vector embedding. Future runs check this memory **before** calling the LLM — reducing cost and latency.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Backend API | Fastify 5, TypeScript, Zod validation |
| Frontend | Next.js 14 (App Router), React 18, TailwindCSS, TanStack Query |
| Test Engine | Playwright, Cucumber.js, TypeScript |
| AI / LLM | OpenAI API (model routing via `ModelRouter`) |
| Queue | BullMQ + Redis (ioredis) |
| Database | PostgreSQL (pg) |
| Auth | JWT + bcrypt |
| Security | `@fastify/helmet`, `@fastify/rate-limit`, `@fastify/cors` |
| Logging | Pino |

---

## Getting Started

### Prerequisites

- Node.js ≥ 18
- PostgreSQL database
- Redis instance
- OpenAI API key

### Install Dependencies

```bash
# Root
npm install

# Backend
cd backend && npm install

# Engine
cd engine && npm install

# Frontend
cd frontend && npm install
```

### Install Playwright Browsers

```bash
cd engine
npx playwright install chromium
```

---

## Environment Variables

Create a `.env` file in `backend/` with at least:

```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/ai_test_engine

# Redis
REDIS_URL=redis://localhost:6379

# OpenAI
OPENAI_API_KEY=sk-...

# Auth
JWT_SECRET=your-secret-here

# Server
PORT=3001
```

Create a `.env.local` file in `frontend/`:

```env
NEXT_PUBLIC_API_URL=http://localhost:3001
```

---

## Running the Project

### All services at once (recommended)

```bash
# From the repo root
npm run dev
```

This starts the backend API and the Next.js frontend concurrently.

### Individually

```bash
# Backend API (port 3001)
npm run backend

# Frontend dashboard (port 3000)
npm run frontend

# Engine (Cucumber test runner)
cd engine && npm run dev
```

---

## Writing Tests

Tests are plain Gherkin `.feature` files placed in `engine/features/`.

```gherkin
Feature: Login

  Scenario: Successful login
    Given I open "https://your-app.com"
    When I click "Login"
    And I enter "user@example.com" into "Email address"
    And I click "Next"
    And I enter "mypassword" into "Password"
    And I click "Sign in"
    Then I should see "Welcome"
```

No selector maintenance is needed. The AI engine resolves each label to the correct DOM element dynamically.

**Supported step patterns (examples):**
- `Given I open "<url>"`
- `When I click "<label>"`
- `And I enter "<text>" into "<field label>"`
- `Then I should see "<text>"`
- `Then I should see error "<message>"`
- `Then I should see password field`

---

## How AI Healing Works

```
Step fails (element not found)
        │
        ▼
HealingAgent re-scans the DOM
        │
        ▼
SimilarityEngine generates embeddings for all candidate elements
        │
        ▼
Check LocatorMemory for a previously healed match
        │
   Found ─────────────────► Use cached locator (no LLM call)
        │
   Not found
        │
        ▼
ResolutionAgent asks LLM: "Which of these elements matches the intent?"
        │
        ▼
Save healed locator to LocatorMemory for future runs
        │
        ▼
Retry step with new locator → execution continues
```

---

## Billing & Cost Control

- Every OpenAI call is logged to `LlmUsageRepo` with model, prompt tokens, completion tokens, and USD cost.
- `BudgetGuard` reads the workspace's configured per-run budget and halts execution before it is exceeded.
- The frontend `billing/` section shows cumulative usage, plan tier, and an upgrade modal.
