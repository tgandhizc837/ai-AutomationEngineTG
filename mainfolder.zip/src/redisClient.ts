import { createClient } from 'redis';

const client = createClient();

client.on('error', (err) => console.error('Redis Client Error', err));

export async function initRedis() {
  await client.connect();
  return client;
}